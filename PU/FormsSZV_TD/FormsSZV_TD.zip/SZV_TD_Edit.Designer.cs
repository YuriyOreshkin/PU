﻿namespace PU.FormsSZV_TD
{
    partial class SZV_TD_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem3 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem4 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem5 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem6 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem7 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem9 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem10 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem11 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem12 = new Telerik.WinControls.UI.RadListDataItem();
            this.DateUnderwriteMaskedEditBox = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.DateUnderwrite = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel24 = new Telerik.WinControls.UI.RadLabel();
            this.Month = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.Year = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.closeBtn = new Telerik.WinControls.UI.RadButton();
            this.saveBtn = new Telerik.WinControls.UI.RadButton();
            this.ConfirmMiddleName = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel26 = new Telerik.WinControls.UI.RadLabel();
            this.ConfirmFirstName = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel25 = new Telerik.WinControls.UI.RadLabel();
            this.ConfirmLastName = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel19 = new Telerik.WinControls.UI.RadLabel();
            this.ConfirmDolgn = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel18 = new Telerik.WinControls.UI.RadLabel();
            this.copySzvtdLabel = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.DateUnderwriteMaskedEditBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateUnderwrite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Month)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Year)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmMiddleName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmFirstName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmLastName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmDolgn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.copySzvtdLabel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // DateUnderwriteMaskedEditBox
            // 
            this.DateUnderwriteMaskedEditBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DateUnderwriteMaskedEditBox.Location = new System.Drawing.Point(482, 17);
            this.DateUnderwriteMaskedEditBox.Mask = "00/00/0000";
            this.DateUnderwriteMaskedEditBox.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.DateUnderwriteMaskedEditBox.Name = "DateUnderwriteMaskedEditBox";
            this.DateUnderwriteMaskedEditBox.NullText = "__.__.____";
            this.DateUnderwriteMaskedEditBox.Size = new System.Drawing.Size(85, 21);
            this.DateUnderwriteMaskedEditBox.TabIndex = 68;
            this.DateUnderwriteMaskedEditBox.TabStop = false;
            this.DateUnderwriteMaskedEditBox.Text = "__.__.____";
            this.DateUnderwriteMaskedEditBox.ThemeName = "Office2013Light";
            this.DateUnderwriteMaskedEditBox.Leave += new System.EventHandler(this.DateUnderwriteMaskedEditBox_Leave);
            // 
            // DateUnderwrite
            // 
            this.DateUnderwrite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DateUnderwrite.CustomFormat = "dd.MM.yyyy";
            this.DateUnderwrite.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateUnderwrite.Location = new System.Drawing.Point(482, 17);
            this.DateUnderwrite.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateUnderwrite.Name = "DateUnderwrite";
            this.DateUnderwrite.NullDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateUnderwrite.Size = new System.Drawing.Size(106, 21);
            this.DateUnderwrite.TabIndex = 69;
            this.DateUnderwrite.TabStop = false;
            this.DateUnderwrite.ThemeName = "Office2013Light";
            this.DateUnderwrite.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateUnderwrite.ValueChanged += new System.EventHandler(this.DateUnderwrite_ValueChanged);
            // 
            // radLabel24
            // 
            this.radLabel24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.radLabel24.Location = new System.Drawing.Point(369, 18);
            this.radLabel24.Name = "radLabel24";
            this.radLabel24.Size = new System.Drawing.Size(103, 19);
            this.radLabel24.TabIndex = 67;
            this.radLabel24.Text = "Дата заполнения";
            this.radLabel24.ThemeName = "Office2013Light";
            // 
            // Month
            // 
            this.Month.AutoCompleteDisplayMember = null;
            this.Month.AutoCompleteValueMember = null;
            this.Month.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            radListDataItem1.Selected = true;
            radListDataItem1.Tag = "1";
            radListDataItem1.Text = "01 - январь";
            radListDataItem2.Tag = "2";
            radListDataItem2.Text = "02 - февраль";
            radListDataItem3.Tag = "3";
            radListDataItem3.Text = "03 - март";
            radListDataItem4.Tag = "4";
            radListDataItem4.Text = "04 - апрель";
            radListDataItem5.Tag = "5";
            radListDataItem5.Text = "05 - май";
            radListDataItem6.Tag = "6";
            radListDataItem6.Text = "06 - июнь";
            radListDataItem7.Tag = "7";
            radListDataItem7.Text = "07 - июль";
            radListDataItem8.Tag = "8";
            radListDataItem8.Text = "08 - август";
            radListDataItem9.Tag = "9";
            radListDataItem9.Text = "09 - сентябрь";
            radListDataItem10.Tag = "10";
            radListDataItem10.Text = "10 - октябрь";
            radListDataItem11.Tag = "11";
            radListDataItem11.Text = "11 - ноябрь";
            radListDataItem12.Tag = "12";
            radListDataItem12.Text = "12 - декабрь";
            this.Month.Items.Add(radListDataItem1);
            this.Month.Items.Add(radListDataItem2);
            this.Month.Items.Add(radListDataItem3);
            this.Month.Items.Add(radListDataItem4);
            this.Month.Items.Add(radListDataItem5);
            this.Month.Items.Add(radListDataItem6);
            this.Month.Items.Add(radListDataItem7);
            this.Month.Items.Add(radListDataItem8);
            this.Month.Items.Add(radListDataItem9);
            this.Month.Items.Add(radListDataItem10);
            this.Month.Items.Add(radListDataItem11);
            this.Month.Items.Add(radListDataItem12);
            this.Month.Location = new System.Drawing.Point(201, 17);
            this.Month.Margin = new System.Windows.Forms.Padding(15, 10, 3, 3);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(133, 21);
            this.Month.TabIndex = 64;
            this.Month.Text = "01 - январь";
            this.Month.ThemeName = "Office2013Light";
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(140, 16);
            this.radLabel1.Margin = new System.Windows.Forms.Padding(30, 10, 3, 3);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(43, 19);
            this.radLabel1.TabIndex = 63;
            this.radLabel1.Text = "Месяц";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // Year
            // 
            this.Year.Location = new System.Drawing.Point(56, 16);
            this.Year.Margin = new System.Windows.Forms.Padding(15, 10, 3, 3);
            this.Year.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.Year.Minimum = new decimal(new int[] {
            2016,
            0,
            0,
            0});
            this.Year.Name = "Year";
            this.Year.NullableValue = new decimal(new int[] {
            2019,
            0,
            0,
            0});
            this.Year.Size = new System.Drawing.Size(51, 21);
            this.Year.TabIndex = 62;
            this.Year.TabStop = false;
            this.Year.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.Year.ThemeName = "Office2013Light";
            this.Year.Value = new decimal(new int[] {
            2019,
            0,
            0,
            0});
            // 
            // radLabel8
            // 
            this.radLabel8.Location = new System.Drawing.Point(12, 16);
            this.radLabel8.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(26, 19);
            this.radLabel8.TabIndex = 61;
            this.radLabel8.Text = "Год";
            this.radLabel8.ThemeName = "Office2013Light";
            // 
            // closeBtn
            // 
            this.closeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBtn.Location = new System.Drawing.Point(478, 176);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(110, 24);
            this.closeBtn.TabIndex = 60;
            this.closeBtn.Text = "Закрыть";
            this.closeBtn.ThemeName = "Office2013Light";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.saveBtn.Location = new System.Drawing.Point(362, 176);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(110, 24);
            this.saveBtn.TabIndex = 59;
            this.saveBtn.Text = "Сохранить";
            this.saveBtn.ThemeName = "Office2013Light";
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // ConfirmMiddleName
            // 
            this.ConfirmMiddleName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ConfirmMiddleName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ConfirmMiddleName.Location = new System.Drawing.Point(183, 134);
            this.ConfirmMiddleName.MaxLength = 40;
            this.ConfirmMiddleName.Name = "ConfirmMiddleName";
            this.ConfirmMiddleName.Size = new System.Drawing.Size(405, 21);
            this.ConfirmMiddleName.TabIndex = 73;
            this.ConfirmMiddleName.ThemeName = "Office2013Light";
            // 
            // radLabel26
            // 
            this.radLabel26.Location = new System.Drawing.Point(12, 135);
            this.radLabel26.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel26.Name = "radLabel26";
            this.radLabel26.Size = new System.Drawing.Size(141, 19);
            this.radLabel26.TabIndex = 77;
            this.radLabel26.Text = "Отчество руководителя";
            this.radLabel26.ThemeName = "Office2013Light";
            // 
            // ConfirmFirstName
            // 
            this.ConfirmFirstName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ConfirmFirstName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ConfirmFirstName.Location = new System.Drawing.Point(183, 110);
            this.ConfirmFirstName.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.ConfirmFirstName.MaxLength = 40;
            this.ConfirmFirstName.Name = "ConfirmFirstName";
            this.ConfirmFirstName.Size = new System.Drawing.Size(405, 21);
            this.ConfirmFirstName.TabIndex = 72;
            this.ConfirmFirstName.ThemeName = "Office2013Light";
            // 
            // radLabel25
            // 
            this.radLabel25.Location = new System.Drawing.Point(12, 111);
            this.radLabel25.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel25.Name = "radLabel25";
            this.radLabel25.Size = new System.Drawing.Size(113, 19);
            this.radLabel25.TabIndex = 76;
            this.radLabel25.Text = "Имя руководителя";
            this.radLabel25.ThemeName = "Office2013Light";
            // 
            // ConfirmLastName
            // 
            this.ConfirmLastName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ConfirmLastName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ConfirmLastName.Location = new System.Drawing.Point(183, 86);
            this.ConfirmLastName.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.ConfirmLastName.MaxLength = 40;
            this.ConfirmLastName.Name = "ConfirmLastName";
            this.ConfirmLastName.Size = new System.Drawing.Size(405, 21);
            this.ConfirmLastName.TabIndex = 71;
            this.ConfirmLastName.ThemeName = "Office2013Light";
            // 
            // radLabel19
            // 
            this.radLabel19.Location = new System.Drawing.Point(12, 87);
            this.radLabel19.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel19.Name = "radLabel19";
            this.radLabel19.Size = new System.Drawing.Size(140, 19);
            this.radLabel19.TabIndex = 75;
            this.radLabel19.Text = "Фамилия руководителя";
            this.radLabel19.ThemeName = "Office2013Light";
            // 
            // ConfirmDolgn
            // 
            this.ConfirmDolgn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ConfirmDolgn.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ConfirmDolgn.Location = new System.Drawing.Point(183, 62);
            this.ConfirmDolgn.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.ConfirmDolgn.MaxLength = 40;
            this.ConfirmDolgn.Name = "ConfirmDolgn";
            this.ConfirmDolgn.Size = new System.Drawing.Size(405, 21);
            this.ConfirmDolgn.TabIndex = 70;
            this.ConfirmDolgn.ThemeName = "Office2013Light";
            // 
            // radLabel18
            // 
            this.radLabel18.Location = new System.Drawing.Point(12, 63);
            this.radLabel18.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel18.Name = "radLabel18";
            this.radLabel18.Size = new System.Drawing.Size(157, 19);
            this.radLabel18.TabIndex = 74;
            this.radLabel18.Text = "Наименование должности";
            this.radLabel18.ThemeName = "Office2013Light";
            // 
            // copySzvtdLabel
            // 
            this.copySzvtdLabel.Location = new System.Drawing.Point(11, 178);
            this.copySzvtdLabel.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.copySzvtdLabel.Name = "copySzvtdLabel";
            this.copySzvtdLabel.Size = new System.Drawing.Size(132, 19);
            this.copySzvtdLabel.TabIndex = 78;
            this.copySzvtdLabel.Text = "Копирование данных!";
            this.copySzvtdLabel.ThemeName = "Office2013Light";
            this.copySzvtdLabel.Visible = false;
            // 
            // SZV_TD_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 215);
            this.Controls.Add(this.copySzvtdLabel);
            this.Controls.Add(this.ConfirmMiddleName);
            this.Controls.Add(this.radLabel26);
            this.Controls.Add(this.ConfirmFirstName);
            this.Controls.Add(this.radLabel25);
            this.Controls.Add(this.ConfirmLastName);
            this.Controls.Add(this.radLabel19);
            this.Controls.Add(this.ConfirmDolgn);
            this.Controls.Add(this.radLabel18);
            this.Controls.Add(this.DateUnderwriteMaskedEditBox);
            this.Controls.Add(this.DateUnderwrite);
            this.Controls.Add(this.radLabel24);
            this.Controls.Add(this.Month);
            this.Controls.Add(this.radLabel1);
            this.Controls.Add(this.Year);
            this.Controls.Add(this.radLabel8);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.saveBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SZV_TD_Edit";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Редактирование Формы СЗВ-ТД";
            this.ThemeName = "Office2013Light";
            this.Load += new System.EventHandler(this.SZV_TD_Edit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DateUnderwriteMaskedEditBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateUnderwrite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Month)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Year)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmMiddleName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmFirstName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmLastName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ConfirmDolgn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.copySzvtdLabel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadMaskedEditBox DateUnderwriteMaskedEditBox;
        public Telerik.WinControls.UI.RadDateTimePicker DateUnderwrite;
        private Telerik.WinControls.UI.RadLabel radLabel24;
        private Telerik.WinControls.UI.RadDropDownList Month;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadSpinEditor Year;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadButton closeBtn;
        private Telerik.WinControls.UI.RadButton saveBtn;
        private Telerik.WinControls.UI.RadTextBox ConfirmMiddleName;
        private Telerik.WinControls.UI.RadLabel radLabel26;
        private Telerik.WinControls.UI.RadTextBox ConfirmFirstName;
        private Telerik.WinControls.UI.RadLabel radLabel25;
        private Telerik.WinControls.UI.RadTextBox ConfirmLastName;
        private Telerik.WinControls.UI.RadLabel radLabel19;
        private Telerik.WinControls.UI.RadTextBox ConfirmDolgn;
        private Telerik.WinControls.UI.RadLabel radLabel18;
        private Telerik.WinControls.UI.RadLabel copySzvtdLabel;
    }
}
