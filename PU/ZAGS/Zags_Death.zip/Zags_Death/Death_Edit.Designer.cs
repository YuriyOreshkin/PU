﻿namespace PU.ZAGS.Zags_Death
{
    partial class Death_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            this.radPageView1 = new Telerik.WinControls.UI.RadPageView();
            this.radPageViewPage1 = new Telerik.WinControls.UI.RadPageViewPage();
            this.CountryBirth = new Telerik.WinControls.UI.RadDropDownList();
            this.PunktBirth = new Telerik.WinControls.UI.RadDropDownList();
            this.DistrBirth = new Telerik.WinControls.UI.RadDropDownList();
            this.RegionBirth = new Telerik.WinControls.UI.RadDropDownList();
            this.Akt_OrgZags = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel18 = new Telerik.WinControls.UI.RadLabel();
            this.Akt_Num = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel12 = new Telerik.WinControls.UI.RadLabel();
            this.Akt_Date_MaskedEditBox = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.Akt_Date = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel17 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel14 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel15 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel16 = new Telerik.WinControls.UI.RadLabel();
            this.Type_PlaceBirth = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel13 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel11 = new Telerik.WinControls.UI.RadLabel();
            this.YearOs_TextBox = new Telerik.WinControls.UI.RadTextBox();
            this.YearOs_SpinEditor = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.MonthOs_TextBox = new Telerik.WinControls.UI.RadTextBox();
            this.MonthOs_SpinEditor = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.DayOs_TextBox = new Telerik.WinControls.UI.RadTextBox();
            this.DayOs_SpinEditor = new Telerik.WinControls.UI.RadSpinEditor();
            this.DateOs_CheckBox = new Telerik.WinControls.UI.RadCheckBox();
            this.DateBirth_MaskedEditBox = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.SexFRadioButton = new Telerik.WinControls.UI.RadRadioButton();
            this.SexMRadioButton = new Telerik.WinControls.UI.RadRadioButton();
            this.FirstName = new Telerik.WinControls.UI.RadTextBox();
            this.LastName = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.MiddleName = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.DateBirth = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radPageViewPage2 = new Telerik.WinControls.UI.RadPageViewPage();
            this.StroenDeath_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.StroenDeath = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel36 = new Telerik.WinControls.UI.RadLabel();
            this.KvartLast_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.KorpLast_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.DomLast_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.KvartDeath_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.KorpDeath_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.DomDeath_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.KvartLast = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel33 = new Telerik.WinControls.UI.RadLabel();
            this.KorpLast = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel34 = new Telerik.WinControls.UI.RadLabel();
            this.DomLast = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel35 = new Telerik.WinControls.UI.RadLabel();
            this.addAbbrLast = new Telerik.WinControls.UI.RadCheckBox();
            this.KvartDeath = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel32 = new Telerik.WinControls.UI.RadLabel();
            this.KorpDeath = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel31 = new Telerik.WinControls.UI.RadLabel();
            this.DomDeath = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel30 = new Telerik.WinControls.UI.RadLabel();
            this.addAbbrDeath = new Telerik.WinControls.UI.RadCheckBox();
            this.radLabel29 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel25 = new Telerik.WinControls.UI.RadLabel();
            this.StreetLast_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.PunktLast_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.CityLast_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.DistrLast_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.RegionLast_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.StreetDeath_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.PunktDeath_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.CityDeath_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.DistrDeath_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.RegionDeath_sokr = new Telerik.WinControls.UI.RadDropDownList();
            this.StreetLast = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel22 = new Telerik.WinControls.UI.RadLabel();
            this.CityLast = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel21 = new Telerik.WinControls.UI.RadLabel();
            this.StreetDeath = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel20 = new Telerik.WinControls.UI.RadLabel();
            this.PunktDeath = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel19 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel48 = new Telerik.WinControls.UI.RadLabel();
            this.dYearOs_TextBox = new Telerik.WinControls.UI.RadTextBox();
            this.dYearOs_SpinEditor = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel43 = new Telerik.WinControls.UI.RadLabel();
            this.dMonthOs_TextBox = new Telerik.WinControls.UI.RadTextBox();
            this.dMonthOs_SpinEditor = new Telerik.WinControls.UI.RadSpinEditor();
            this.radLabel44 = new Telerik.WinControls.UI.RadLabel();
            this.dDayOs_TextBox = new Telerik.WinControls.UI.RadTextBox();
            this.dDayOs_SpinEditor = new Telerik.WinControls.UI.RadSpinEditor();
            this.dDateOs_CheckBox = new Telerik.WinControls.UI.RadCheckBox();
            this.PunktLast = new Telerik.WinControls.UI.RadDropDownList();
            this.DistrLast = new Telerik.WinControls.UI.RadDropDownList();
            this.RegionLast = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel39 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel40 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel41 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel23 = new Telerik.WinControls.UI.RadLabel();
            this.DateDeath_MaskedEditBox = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel49 = new Telerik.WinControls.UI.RadLabel();
            this.DateDeath = new Telerik.WinControls.UI.RadDateTimePicker();
            this.CityDeath = new Telerik.WinControls.UI.RadDropDownList();
            this.DistrDeath = new Telerik.WinControls.UI.RadDropDownList();
            this.RegionDeath = new Telerik.WinControls.UI.RadDropDownList();
            this.radLabel26 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel27 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel28 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel24 = new Telerik.WinControls.UI.RadLabel();
            this.closeBtn = new Telerik.WinControls.UI.RadButton();
            this.saveBtn = new Telerik.WinControls.UI.RadButton();
            this.StroenLast_sokr = new Telerik.WinControls.UI.RadTextBox();
            this.StroenLast = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel37 = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).BeginInit();
            this.radPageView1.SuspendLayout();
            this.radPageViewPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CountryBirth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktBirth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrBirth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionBirth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_OrgZags)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_Num)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_Date_MaskedEditBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_Date)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Type_PlaceBirth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YearOs_TextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YearOs_SpinEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MonthOs_TextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MonthOs_SpinEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DayOs_TextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DayOs_SpinEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateOs_CheckBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateBirth_MaskedEditBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SexFRadioButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SexMRadioButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FirstName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LastName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MiddleName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateBirth)).BeginInit();
            this.radPageViewPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StroenDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StroenDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addAbbrLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addAbbrDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionDeath_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dYearOs_TextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dYearOs_SpinEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMonthOs_TextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMonthOs_SpinEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dDayOs_TextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dDayOs_SpinEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dDateOs_CheckBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDeath_MaskedEditBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionDeath)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StroenLast_sokr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StroenLast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radPageView1
            // 
            this.radPageView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.radPageView1.Controls.Add(this.radPageViewPage1);
            this.radPageView1.Controls.Add(this.radPageViewPage2);
            this.radPageView1.DefaultPage = this.radPageViewPage1;
            this.radPageView1.Location = new System.Drawing.Point(12, 12);
            this.radPageView1.Name = "radPageView1";
            this.radPageView1.SelectedPage = this.radPageViewPage2;
            this.radPageView1.Size = new System.Drawing.Size(468, 549);
            this.radPageView1.TabIndex = 0;
            this.radPageView1.Text = "radPageView1";
            this.radPageView1.ThemeName = "Office2013Light";
            ((Telerik.WinControls.UI.RadPageViewStripElement)(this.radPageView1.GetChildAt(0))).StripButtons = Telerik.WinControls.UI.StripViewButtons.None;
            // 
            // radPageViewPage1
            // 
            this.radPageViewPage1.Controls.Add(this.CountryBirth);
            this.radPageViewPage1.Controls.Add(this.PunktBirth);
            this.radPageViewPage1.Controls.Add(this.DistrBirth);
            this.radPageViewPage1.Controls.Add(this.RegionBirth);
            this.radPageViewPage1.Controls.Add(this.Akt_OrgZags);
            this.radPageViewPage1.Controls.Add(this.radLabel18);
            this.radPageViewPage1.Controls.Add(this.Akt_Num);
            this.radPageViewPage1.Controls.Add(this.radLabel12);
            this.radPageViewPage1.Controls.Add(this.Akt_Date_MaskedEditBox);
            this.radPageViewPage1.Controls.Add(this.radLabel3);
            this.radPageViewPage1.Controls.Add(this.Akt_Date);
            this.radPageViewPage1.Controls.Add(this.radLabel2);
            this.radPageViewPage1.Controls.Add(this.radLabel1);
            this.radPageViewPage1.Controls.Add(this.radLabel17);
            this.radPageViewPage1.Controls.Add(this.radLabel14);
            this.radPageViewPage1.Controls.Add(this.radLabel15);
            this.radPageViewPage1.Controls.Add(this.radLabel16);
            this.radPageViewPage1.Controls.Add(this.Type_PlaceBirth);
            this.radPageViewPage1.Controls.Add(this.radLabel13);
            this.radPageViewPage1.Controls.Add(this.radLabel11);
            this.radPageViewPage1.Controls.Add(this.YearOs_TextBox);
            this.radPageViewPage1.Controls.Add(this.YearOs_SpinEditor);
            this.radPageViewPage1.Controls.Add(this.radLabel10);
            this.radPageViewPage1.Controls.Add(this.MonthOs_TextBox);
            this.radPageViewPage1.Controls.Add(this.MonthOs_SpinEditor);
            this.radPageViewPage1.Controls.Add(this.radLabel9);
            this.radPageViewPage1.Controls.Add(this.DayOs_TextBox);
            this.radPageViewPage1.Controls.Add(this.DayOs_SpinEditor);
            this.radPageViewPage1.Controls.Add(this.DateOs_CheckBox);
            this.radPageViewPage1.Controls.Add(this.DateBirth_MaskedEditBox);
            this.radPageViewPage1.Controls.Add(this.SexFRadioButton);
            this.radPageViewPage1.Controls.Add(this.SexMRadioButton);
            this.radPageViewPage1.Controls.Add(this.FirstName);
            this.radPageViewPage1.Controls.Add(this.LastName);
            this.radPageViewPage1.Controls.Add(this.radLabel4);
            this.radPageViewPage1.Controls.Add(this.MiddleName);
            this.radPageViewPage1.Controls.Add(this.radLabel5);
            this.radPageViewPage1.Controls.Add(this.radLabel6);
            this.radPageViewPage1.Controls.Add(this.radLabel7);
            this.radPageViewPage1.Controls.Add(this.radLabel8);
            this.radPageViewPage1.Controls.Add(this.DateBirth);
            this.radPageViewPage1.ItemSize = new System.Drawing.SizeF(144F, 27F);
            this.radPageViewPage1.Location = new System.Drawing.Point(5, 31);
            this.radPageViewPage1.Name = "radPageViewPage1";
            this.radPageViewPage1.Size = new System.Drawing.Size(458, 526);
            this.radPageViewPage1.Text = "Сведения об умершем";
            // 
            // CountryBirth
            // 
            this.CountryBirth.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CountryBirth.Location = new System.Drawing.Point(119, 280);
            this.CountryBirth.Name = "CountryBirth";
            this.CountryBirth.Size = new System.Drawing.Size(327, 21);
            this.CountryBirth.TabIndex = 15;
            this.CountryBirth.Text = "Российская Федерация";
            this.CountryBirth.ThemeName = "Office2013Light";
            // 
            // PunktBirth
            // 
            this.PunktBirth.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PunktBirth.Location = new System.Drawing.Point(119, 202);
            this.PunktBirth.Name = "PunktBirth";
            this.PunktBirth.Size = new System.Drawing.Size(327, 21);
            this.PunktBirth.TabIndex = 12;
            this.PunktBirth.ThemeName = "Office2013Light";
            // 
            // DistrBirth
            // 
            this.DistrBirth.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DistrBirth.Location = new System.Drawing.Point(119, 229);
            this.DistrBirth.Name = "DistrBirth";
            this.DistrBirth.Size = new System.Drawing.Size(327, 21);
            this.DistrBirth.TabIndex = 13;
            this.DistrBirth.ThemeName = "Office2013Light";
            // 
            // RegionBirth
            // 
            this.RegionBirth.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.RegionBirth.Location = new System.Drawing.Point(119, 255);
            this.RegionBirth.Name = "RegionBirth";
            this.RegionBirth.Size = new System.Drawing.Size(327, 21);
            this.RegionBirth.TabIndex = 14;
            this.RegionBirth.ThemeName = "Office2013Light";
            // 
            // Akt_OrgZags
            // 
            this.Akt_OrgZags.Location = new System.Drawing.Point(119, 364);
            this.Akt_OrgZags.MaxLength = 500;
            this.Akt_OrgZags.Name = "Akt_OrgZags";
            this.Akt_OrgZags.Size = new System.Drawing.Size(327, 21);
            this.Akt_OrgZags.TabIndex = 19;
            this.Akt_OrgZags.ThemeName = "Office2013Light";
            // 
            // radLabel18
            // 
            this.radLabel18.Location = new System.Drawing.Point(3, 365);
            this.radLabel18.Name = "radLabel18";
            this.radLabel18.Size = new System.Drawing.Size(35, 19);
            this.radLabel18.TabIndex = 64;
            this.radLabel18.Text = "ЗАГС";
            this.radLabel18.ThemeName = "Office2013Light";
            // 
            // Akt_Num
            // 
            this.Akt_Num.Location = new System.Drawing.Point(119, 339);
            this.Akt_Num.MaxLength = 30;
            this.Akt_Num.Name = "Akt_Num";
            this.Akt_Num.Size = new System.Drawing.Size(133, 21);
            this.Akt_Num.TabIndex = 16;
            this.Akt_Num.ThemeName = "Office2013Light";
            // 
            // radLabel12
            // 
            this.radLabel12.Location = new System.Drawing.Point(3, 340);
            this.radLabel12.Name = "radLabel12";
            this.radLabel12.Size = new System.Drawing.Size(45, 19);
            this.radLabel12.TabIndex = 62;
            this.radLabel12.Text = "Номер";
            this.radLabel12.ThemeName = "Office2013Light";
            // 
            // Akt_Date_MaskedEditBox
            // 
            this.Akt_Date_MaskedEditBox.Location = new System.Drawing.Point(361, 339);
            this.Akt_Date_MaskedEditBox.Mask = "00/00/0000";
            this.Akt_Date_MaskedEditBox.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.Akt_Date_MaskedEditBox.Name = "Akt_Date_MaskedEditBox";
            this.Akt_Date_MaskedEditBox.NullText = "__.__.____";
            this.Akt_Date_MaskedEditBox.Size = new System.Drawing.Size(64, 21);
            this.Akt_Date_MaskedEditBox.TabIndex = 17;
            this.Akt_Date_MaskedEditBox.TabStop = false;
            this.Akt_Date_MaskedEditBox.Text = "__.__.____";
            this.Akt_Date_MaskedEditBox.ThemeName = "Office2013Light";
            this.Akt_Date_MaskedEditBox.Leave += new System.EventHandler(this.cAkt_Date_MaskedEditBox_Leave);
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(279, 340);
            this.radLabel3.Margin = new System.Windows.Forms.Padding(3, 5, 0, 3);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(79, 19);
            this.radLabel3.TabIndex = 60;
            this.radLabel3.Text = "Дата выдачи";
            this.radLabel3.ThemeName = "Office2013Light";
            // 
            // Akt_Date
            // 
            this.Akt_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.Akt_Date.Location = new System.Drawing.Point(361, 339);
            this.Akt_Date.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.Akt_Date.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.Akt_Date.Name = "Akt_Date";
            this.Akt_Date.NullDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.Akt_Date.Size = new System.Drawing.Size(85, 21);
            this.Akt_Date.TabIndex = 18;
            this.Akt_Date.TabStop = false;
            this.Akt_Date.ThemeName = "Office2013Light";
            this.Akt_Date.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.Akt_Date.ValueChanged += new System.EventHandler(this.cAkt_Date_ValueChanged);
            // 
            // radLabel2
            // 
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.radLabel2.Location = new System.Drawing.Point(3, 315);
            this.radLabel2.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(204, 19);
            this.radLabel2.TabIndex = 57;
            this.radLabel2.Text = "Реквизиты записи акта о смерти";
            this.radLabel2.ThemeName = "Office2013Light";
            // 
            // radLabel1
            // 
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.radLabel1.Location = new System.Drawing.Point(3, 146);
            this.radLabel1.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(110, 19);
            this.radLabel1.TabIndex = 56;
            this.radLabel1.Text = "Место рождения";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // radLabel17
            // 
            this.radLabel17.Location = new System.Drawing.Point(3, 280);
            this.radLabel17.Name = "radLabel17";
            this.radLabel17.Size = new System.Drawing.Size(46, 19);
            this.radLabel17.TabIndex = 55;
            this.radLabel17.Text = "Страна";
            this.radLabel17.ThemeName = "Office2013Light";
            // 
            // radLabel14
            // 
            this.radLabel14.Location = new System.Drawing.Point(3, 202);
            this.radLabel14.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel14.Name = "radLabel14";
            this.radLabel14.Size = new System.Drawing.Size(112, 19);
            this.radLabel14.TabIndex = 51;
            this.radLabel14.Text = "Населенный пункт";
            this.radLabel14.ThemeName = "Office2013Light";
            // 
            // radLabel15
            // 
            this.radLabel15.Location = new System.Drawing.Point(3, 229);
            this.radLabel15.Name = "radLabel15";
            this.radLabel15.Size = new System.Drawing.Size(41, 19);
            this.radLabel15.TabIndex = 52;
            this.radLabel15.Text = "Район";
            this.radLabel15.ThemeName = "Office2013Light";
            // 
            // radLabel16
            // 
            this.radLabel16.Location = new System.Drawing.Point(3, 255);
            this.radLabel16.Name = "radLabel16";
            this.radLabel16.Size = new System.Drawing.Size(96, 19);
            this.radLabel16.TabIndex = 53;
            this.radLabel16.Text = "Регион, область";
            this.radLabel16.ThemeName = "Office2013Light";
            // 
            // Type_PlaceBirth
            // 
            this.Type_PlaceBirth.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList;
            radListDataItem1.Selected = true;
            radListDataItem1.Tag = "1";
            radListDataItem1.Text = "СТАНДАРТ";
            radListDataItem2.Tag = "2";
            radListDataItem2.Text = "ОСОБОЕ";
            this.Type_PlaceBirth.Items.Add(radListDataItem1);
            this.Type_PlaceBirth.Items.Add(radListDataItem2);
            this.Type_PlaceBirth.Location = new System.Drawing.Point(119, 172);
            this.Type_PlaceBirth.Name = "Type_PlaceBirth";
            this.Type_PlaceBirth.Size = new System.Drawing.Size(133, 21);
            this.Type_PlaceBirth.TabIndex = 11;
            this.Type_PlaceBirth.Text = "СТАНДАРТ";
            this.Type_PlaceBirth.ThemeName = "Office2013Light";
            // 
            // radLabel13
            // 
            this.radLabel13.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.radLabel13.Location = new System.Drawing.Point(3, 171);
            this.radLabel13.Name = "radLabel13";
            this.radLabel13.Size = new System.Drawing.Size(27, 19);
            this.radLabel13.TabIndex = 46;
            this.radLabel13.Text = "Тип";
            this.radLabel13.ThemeName = "Office2013Light";
            // 
            // radLabel11
            // 
            this.radLabel11.Location = new System.Drawing.Point(421, 117);
            this.radLabel11.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.radLabel11.Name = "radLabel11";
            this.radLabel11.Size = new System.Drawing.Size(25, 19);
            this.radLabel11.TabIndex = 45;
            this.radLabel11.Text = "год";
            this.radLabel11.ThemeName = "Office2013Light";
            // 
            // YearOs_TextBox
            // 
            this.YearOs_TextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.YearOs_TextBox.Enabled = false;
            this.YearOs_TextBox.Location = new System.Drawing.Point(374, 115);
            this.YearOs_TextBox.MaxLength = 4;
            this.YearOs_TextBox.Name = "YearOs_TextBox";
            this.YearOs_TextBox.Size = new System.Drawing.Size(31, 21);
            this.YearOs_TextBox.TabIndex = 10;
            this.YearOs_TextBox.ThemeName = "Office2013Light";
            this.YearOs_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cYearOs_TextBox_KeyPress);
            this.YearOs_TextBox.Leave += new System.EventHandler(this.cYearOs_TextBox_Leave);
            // 
            // YearOs_SpinEditor
            // 
            this.YearOs_SpinEditor.Enabled = false;
            this.YearOs_SpinEditor.Location = new System.Drawing.Point(374, 115);
            this.YearOs_SpinEditor.Maximum = new decimal(new int[] {
            2100,
            0,
            0,
            0});
            this.YearOs_SpinEditor.Name = "YearOs_SpinEditor";
            this.YearOs_SpinEditor.Size = new System.Drawing.Size(44, 21);
            this.YearOs_SpinEditor.TabIndex = 43;
            this.YearOs_SpinEditor.TabStop = false;
            this.YearOs_SpinEditor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.YearOs_SpinEditor.ThemeName = "Office2013Light";
            this.YearOs_SpinEditor.ValueChanged += new System.EventHandler(this.cYearOs_SpinEditor_ValueChanged);
            // 
            // radLabel10
            // 
            this.radLabel10.Location = new System.Drawing.Point(330, 117);
            this.radLabel10.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(41, 19);
            this.radLabel10.TabIndex = 42;
            this.radLabel10.Text = "месяц";
            this.radLabel10.ThemeName = "Office2013Light";
            // 
            // MonthOs_TextBox
            // 
            this.MonthOs_TextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.MonthOs_TextBox.Enabled = false;
            this.MonthOs_TextBox.Location = new System.Drawing.Point(289, 115);
            this.MonthOs_TextBox.MaxLength = 2;
            this.MonthOs_TextBox.Name = "MonthOs_TextBox";
            this.MonthOs_TextBox.Size = new System.Drawing.Size(23, 21);
            this.MonthOs_TextBox.TabIndex = 9;
            this.MonthOs_TextBox.ThemeName = "Office2013Light";
            this.MonthOs_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cMonthOs_TextBox_KeyPress);
            this.MonthOs_TextBox.Leave += new System.EventHandler(this.cMonthOs_TextBox_Leave);
            // 
            // MonthOs_SpinEditor
            // 
            this.MonthOs_SpinEditor.Enabled = false;
            this.MonthOs_SpinEditor.Location = new System.Drawing.Point(289, 115);
            this.MonthOs_SpinEditor.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.MonthOs_SpinEditor.Name = "MonthOs_SpinEditor";
            this.MonthOs_SpinEditor.Size = new System.Drawing.Size(36, 21);
            this.MonthOs_SpinEditor.TabIndex = 40;
            this.MonthOs_SpinEditor.TabStop = false;
            this.MonthOs_SpinEditor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.MonthOs_SpinEditor.ThemeName = "Office2013Light";
            this.MonthOs_SpinEditor.ValueChanged += new System.EventHandler(this.cMonthOs_SpinEditor_ValueChanged);
            // 
            // radLabel9
            // 
            this.radLabel9.Location = new System.Drawing.Point(253, 118);
            this.radLabel9.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(33, 19);
            this.radLabel9.TabIndex = 39;
            this.radLabel9.Text = "день";
            this.radLabel9.ThemeName = "Office2013Light";
            // 
            // DayOs_TextBox
            // 
            this.DayOs_TextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.DayOs_TextBox.Enabled = false;
            this.DayOs_TextBox.Location = new System.Drawing.Point(214, 116);
            this.DayOs_TextBox.MaxLength = 2;
            this.DayOs_TextBox.Name = "DayOs_TextBox";
            this.DayOs_TextBox.Size = new System.Drawing.Size(23, 21);
            this.DayOs_TextBox.TabIndex = 8;
            this.DayOs_TextBox.ThemeName = "Office2013Light";
            this.DayOs_TextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cDayOs_TextBox_KeyPress);
            this.DayOs_TextBox.Leave += new System.EventHandler(this.cDayOs_TextBox_Leave);
            // 
            // DayOs_SpinEditor
            // 
            this.DayOs_SpinEditor.Enabled = false;
            this.DayOs_SpinEditor.Location = new System.Drawing.Point(216, 116);
            this.DayOs_SpinEditor.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.DayOs_SpinEditor.Name = "DayOs_SpinEditor";
            this.DayOs_SpinEditor.Size = new System.Drawing.Size(36, 21);
            this.DayOs_SpinEditor.TabIndex = 37;
            this.DayOs_SpinEditor.TabStop = false;
            this.DayOs_SpinEditor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.DayOs_SpinEditor.ThemeName = "Office2013Light";
            this.DayOs_SpinEditor.ValueChanged += new System.EventHandler(this.cDayOs_SpinEditor_ValueChanged);
            // 
            // DateOs_CheckBox
            // 
            this.DateOs_CheckBox.Location = new System.Drawing.Point(214, 91);
            this.DateOs_CheckBox.Name = "DateOs_CheckBox";
            this.DateOs_CheckBox.Size = new System.Drawing.Size(156, 19);
            this.DateOs_CheckBox.TabIndex = 5;
            this.DateOs_CheckBox.Text = "Особая Дата рождения";
            this.DateOs_CheckBox.ThemeName = "Office2013Light";
            this.DateOs_CheckBox.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.cDateOs_CheckBox_ToggleStateChanged);
            // 
            // DateBirth_MaskedEditBox
            // 
            this.DateBirth_MaskedEditBox.Location = new System.Drawing.Point(119, 116);
            this.DateBirth_MaskedEditBox.Mask = "00/00/0000";
            this.DateBirth_MaskedEditBox.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.DateBirth_MaskedEditBox.Name = "DateBirth_MaskedEditBox";
            this.DateBirth_MaskedEditBox.NullText = "__.__.____";
            this.DateBirth_MaskedEditBox.Size = new System.Drawing.Size(64, 21);
            this.DateBirth_MaskedEditBox.TabIndex = 6;
            this.DateBirth_MaskedEditBox.TabStop = false;
            this.DateBirth_MaskedEditBox.Text = "__.__.____";
            this.DateBirth_MaskedEditBox.ThemeName = "Office2013Light";
            this.DateBirth_MaskedEditBox.Leave += new System.EventHandler(this.cDateBirth_MaskedEditBox_Leave);
            // 
            // SexFRadioButton
            // 
            this.SexFRadioButton.Location = new System.Drawing.Point(160, 91);
            this.SexFRadioButton.Name = "SexFRadioButton";
            this.SexFRadioButton.Size = new System.Drawing.Size(34, 19);
            this.SexFRadioButton.TabIndex = 4;
            this.SexFRadioButton.Text = "Ж";
            this.SexFRadioButton.ThemeName = "Office2013Light";
            // 
            // SexMRadioButton
            // 
            this.SexMRadioButton.Location = new System.Drawing.Point(119, 91);
            this.SexMRadioButton.Name = "SexMRadioButton";
            this.SexMRadioButton.Size = new System.Drawing.Size(35, 19);
            this.SexMRadioButton.TabIndex = 3;
            this.SexMRadioButton.Text = "М";
            this.SexMRadioButton.ThemeName = "Office2013Light";
            // 
            // FirstName
            // 
            this.FirstName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.FirstName.Location = new System.Drawing.Point(119, 31);
            this.FirstName.MaxLength = 40;
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(327, 21);
            this.FirstName.TabIndex = 1;
            this.FirstName.ThemeName = "Office2013Light";
            // 
            // LastName
            // 
            this.LastName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.LastName.Location = new System.Drawing.Point(119, 4);
            this.LastName.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.LastName.MaxLength = 40;
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(327, 21);
            this.LastName.TabIndex = 0;
            this.LastName.ThemeName = "Office2013Light";
            // 
            // radLabel4
            // 
            this.radLabel4.Location = new System.Drawing.Point(3, 5);
            this.radLabel4.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(58, 19);
            this.radLabel4.TabIndex = 28;
            this.radLabel4.Text = "Фамилия";
            this.radLabel4.ThemeName = "Office2013Light";
            // 
            // MiddleName
            // 
            this.MiddleName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.MiddleName.Location = new System.Drawing.Point(119, 58);
            this.MiddleName.MaxLength = 40;
            this.MiddleName.Name = "MiddleName";
            this.MiddleName.Size = new System.Drawing.Size(327, 21);
            this.MiddleName.TabIndex = 2;
            this.MiddleName.ThemeName = "Office2013Light";
            // 
            // radLabel5
            // 
            this.radLabel5.Location = new System.Drawing.Point(3, 33);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(31, 19);
            this.radLabel5.TabIndex = 31;
            this.radLabel5.Text = "Имя";
            this.radLabel5.ThemeName = "Office2013Light";
            // 
            // radLabel6
            // 
            this.radLabel6.Location = new System.Drawing.Point(3, 59);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(59, 19);
            this.radLabel6.TabIndex = 33;
            this.radLabel6.Text = "Отчество";
            this.radLabel6.ThemeName = "Office2013Light";
            // 
            // radLabel7
            // 
            this.radLabel7.Location = new System.Drawing.Point(3, 91);
            this.radLabel7.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(29, 19);
            this.radLabel7.TabIndex = 34;
            this.radLabel7.Text = "Пол";
            this.radLabel7.ThemeName = "Office2013Light";
            // 
            // radLabel8
            // 
            this.radLabel8.Location = new System.Drawing.Point(3, 118);
            this.radLabel8.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(94, 19);
            this.radLabel8.TabIndex = 35;
            this.radLabel8.Text = "Дата рождения";
            this.radLabel8.ThemeName = "Office2013Light";
            // 
            // DateBirth
            // 
            this.DateBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateBirth.Location = new System.Drawing.Point(119, 116);
            this.DateBirth.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.DateBirth.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateBirth.Name = "DateBirth";
            this.DateBirth.NullDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateBirth.Size = new System.Drawing.Size(85, 21);
            this.DateBirth.TabIndex = 7;
            this.DateBirth.TabStop = false;
            this.DateBirth.ThemeName = "Office2013Light";
            this.DateBirth.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateBirth.ValueChanged += new System.EventHandler(this.cDateBirth_ValueChanged);
            // 
            // radPageViewPage2
            // 
            this.radPageViewPage2.Controls.Add(this.StroenLast_sokr);
            this.radPageViewPage2.Controls.Add(this.StroenLast);
            this.radPageViewPage2.Controls.Add(this.radLabel37);
            this.radPageViewPage2.Controls.Add(this.StroenDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.StroenDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel36);
            this.radPageViewPage2.Controls.Add(this.KvartLast_sokr);
            this.radPageViewPage2.Controls.Add(this.KorpLast_sokr);
            this.radPageViewPage2.Controls.Add(this.DomLast_sokr);
            this.radPageViewPage2.Controls.Add(this.KvartDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.KorpDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.DomDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.KvartLast);
            this.radPageViewPage2.Controls.Add(this.radLabel33);
            this.radPageViewPage2.Controls.Add(this.KorpLast);
            this.radPageViewPage2.Controls.Add(this.radLabel34);
            this.radPageViewPage2.Controls.Add(this.DomLast);
            this.radPageViewPage2.Controls.Add(this.radLabel35);
            this.radPageViewPage2.Controls.Add(this.addAbbrLast);
            this.radPageViewPage2.Controls.Add(this.KvartDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel32);
            this.radPageViewPage2.Controls.Add(this.KorpDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel31);
            this.radPageViewPage2.Controls.Add(this.DomDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel30);
            this.radPageViewPage2.Controls.Add(this.addAbbrDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel29);
            this.radPageViewPage2.Controls.Add(this.radLabel25);
            this.radPageViewPage2.Controls.Add(this.StreetLast_sokr);
            this.radPageViewPage2.Controls.Add(this.PunktLast_sokr);
            this.radPageViewPage2.Controls.Add(this.CityLast_sokr);
            this.radPageViewPage2.Controls.Add(this.DistrLast_sokr);
            this.radPageViewPage2.Controls.Add(this.RegionLast_sokr);
            this.radPageViewPage2.Controls.Add(this.StreetDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.PunktDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.CityDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.DistrDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.RegionDeath_sokr);
            this.radPageViewPage2.Controls.Add(this.StreetLast);
            this.radPageViewPage2.Controls.Add(this.radLabel22);
            this.radPageViewPage2.Controls.Add(this.CityLast);
            this.radPageViewPage2.Controls.Add(this.radLabel21);
            this.radPageViewPage2.Controls.Add(this.StreetDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel20);
            this.radPageViewPage2.Controls.Add(this.PunktDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel19);
            this.radPageViewPage2.Controls.Add(this.radLabel48);
            this.radPageViewPage2.Controls.Add(this.dYearOs_TextBox);
            this.radPageViewPage2.Controls.Add(this.dYearOs_SpinEditor);
            this.radPageViewPage2.Controls.Add(this.radLabel43);
            this.radPageViewPage2.Controls.Add(this.dMonthOs_TextBox);
            this.radPageViewPage2.Controls.Add(this.dMonthOs_SpinEditor);
            this.radPageViewPage2.Controls.Add(this.radLabel44);
            this.radPageViewPage2.Controls.Add(this.dDayOs_TextBox);
            this.radPageViewPage2.Controls.Add(this.dDayOs_SpinEditor);
            this.radPageViewPage2.Controls.Add(this.dDateOs_CheckBox);
            this.radPageViewPage2.Controls.Add(this.PunktLast);
            this.radPageViewPage2.Controls.Add(this.DistrLast);
            this.radPageViewPage2.Controls.Add(this.RegionLast);
            this.radPageViewPage2.Controls.Add(this.radLabel39);
            this.radPageViewPage2.Controls.Add(this.radLabel40);
            this.radPageViewPage2.Controls.Add(this.radLabel41);
            this.radPageViewPage2.Controls.Add(this.radLabel23);
            this.radPageViewPage2.Controls.Add(this.DateDeath_MaskedEditBox);
            this.radPageViewPage2.Controls.Add(this.radLabel49);
            this.radPageViewPage2.Controls.Add(this.DateDeath);
            this.radPageViewPage2.Controls.Add(this.CityDeath);
            this.radPageViewPage2.Controls.Add(this.DistrDeath);
            this.radPageViewPage2.Controls.Add(this.RegionDeath);
            this.radPageViewPage2.Controls.Add(this.radLabel26);
            this.radPageViewPage2.Controls.Add(this.radLabel27);
            this.radPageViewPage2.Controls.Add(this.radLabel28);
            this.radPageViewPage2.Controls.Add(this.radLabel24);
            this.radPageViewPage2.ItemSize = new System.Drawing.SizeF(132F, 27F);
            this.radPageViewPage2.Location = new System.Drawing.Point(5, 31);
            this.radPageViewPage2.Name = "radPageViewPage2";
            this.radPageViewPage2.Size = new System.Drawing.Size(458, 513);
            this.radPageViewPage2.Text = "Дата и место смерти";
            // 
            // StroenDeath_sokr
            // 
            this.StroenDeath_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.StroenDeath_sokr.Enabled = false;
            this.StroenDeath_sokr.Location = new System.Drawing.Point(288, 196);
            this.StroenDeath_sokr.Name = "StroenDeath_sokr";
            this.StroenDeath_sokr.Size = new System.Drawing.Size(43, 21);
            this.StroenDeath_sokr.TabIndex = 166;
            this.StroenDeath_sokr.Text = "СТР.";
            this.StroenDeath_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.StroenDeath_sokr.ThemeName = "Office2013Light";
            // 
            // StroenDeath
            // 
            this.StroenDeath.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.StroenDeath.Location = new System.Drawing.Point(337, 196);
            this.StroenDeath.Name = "StroenDeath";
            this.StroenDeath.Size = new System.Drawing.Size(33, 21);
            this.StroenDeath.TabIndex = 167;
            this.StroenDeath.ThemeName = "Office2013Light";
            // 
            // radLabel36
            // 
            this.radLabel36.Location = new System.Drawing.Point(230, 197);
            this.radLabel36.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel36.Name = "radLabel36";
            this.radLabel36.Size = new System.Drawing.Size(61, 19);
            this.radLabel36.TabIndex = 168;
            this.radLabel36.Text = "Строение";
            this.radLabel36.ThemeName = "Office2013Light";
            // 
            // KvartLast_sokr
            // 
            this.KvartLast_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KvartLast_sokr.Enabled = false;
            this.KvartLast_sokr.Location = new System.Drawing.Point(288, 462);
            this.KvartLast_sokr.Name = "KvartLast_sokr";
            this.KvartLast_sokr.Size = new System.Drawing.Size(43, 21);
            this.KvartLast_sokr.TabIndex = 34;
            this.KvartLast_sokr.Text = "КВ.";
            this.KvartLast_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.KvartLast_sokr.ThemeName = "Office2013Light";
            // 
            // KorpLast_sokr
            // 
            this.KorpLast_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KorpLast_sokr.Enabled = false;
            this.KorpLast_sokr.Location = new System.Drawing.Point(119, 462);
            this.KorpLast_sokr.Name = "KorpLast_sokr";
            this.KorpLast_sokr.Size = new System.Drawing.Size(41, 21);
            this.KorpLast_sokr.TabIndex = 32;
            this.KorpLast_sokr.Text = "КОРП.";
            this.KorpLast_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.KorpLast_sokr.ThemeName = "Office2013Light";
            // 
            // DomLast_sokr
            // 
            this.DomLast_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.DomLast_sokr.Enabled = false;
            this.DomLast_sokr.Location = new System.Drawing.Point(119, 435);
            this.DomLast_sokr.Name = "DomLast_sokr";
            this.DomLast_sokr.Size = new System.Drawing.Size(41, 21);
            this.DomLast_sokr.TabIndex = 30;
            this.DomLast_sokr.Text = "Д.";
            this.DomLast_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.DomLast_sokr.ThemeName = "Office2013Light";
            // 
            // KvartDeath_sokr
            // 
            this.KvartDeath_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KvartDeath_sokr.Enabled = false;
            this.KvartDeath_sokr.Location = new System.Drawing.Point(288, 223);
            this.KvartDeath_sokr.Name = "KvartDeath_sokr";
            this.KvartDeath_sokr.Size = new System.Drawing.Size(43, 21);
            this.KvartDeath_sokr.TabIndex = 16;
            this.KvartDeath_sokr.Text = "КВ.";
            this.KvartDeath_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.KvartDeath_sokr.ThemeName = "Office2013Light";
            // 
            // KorpDeath_sokr
            // 
            this.KorpDeath_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KorpDeath_sokr.Enabled = false;
            this.KorpDeath_sokr.Location = new System.Drawing.Point(119, 222);
            this.KorpDeath_sokr.Name = "KorpDeath_sokr";
            this.KorpDeath_sokr.Size = new System.Drawing.Size(41, 21);
            this.KorpDeath_sokr.TabIndex = 14;
            this.KorpDeath_sokr.Text = "КОРП.";
            this.KorpDeath_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.KorpDeath_sokr.ThemeName = "Office2013Light";
            // 
            // DomDeath_sokr
            // 
            this.DomDeath_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.DomDeath_sokr.Enabled = false;
            this.DomDeath_sokr.Location = new System.Drawing.Point(119, 195);
            this.DomDeath_sokr.Name = "DomDeath_sokr";
            this.DomDeath_sokr.Size = new System.Drawing.Size(41, 21);
            this.DomDeath_sokr.TabIndex = 12;
            this.DomDeath_sokr.Text = "Д.";
            this.DomDeath_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.DomDeath_sokr.ThemeName = "Office2013Light";
            // 
            // KvartLast
            // 
            this.KvartLast.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KvartLast.Location = new System.Drawing.Point(337, 462);
            this.KvartLast.Name = "KvartLast";
            this.KvartLast.Size = new System.Drawing.Size(33, 21);
            this.KvartLast.TabIndex = 35;
            this.KvartLast.ThemeName = "Office2013Light";
            // 
            // radLabel33
            // 
            this.radLabel33.Location = new System.Drawing.Point(230, 463);
            this.radLabel33.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel33.Name = "radLabel33";
            this.radLabel33.Size = new System.Drawing.Size(60, 19);
            this.radLabel33.TabIndex = 165;
            this.radLabel33.Text = "Квартира";
            this.radLabel33.ThemeName = "Office2013Light";
            // 
            // KorpLast
            // 
            this.KorpLast.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KorpLast.Location = new System.Drawing.Point(167, 462);
            this.KorpLast.Name = "KorpLast";
            this.KorpLast.Size = new System.Drawing.Size(33, 21);
            this.KorpLast.TabIndex = 33;
            this.KorpLast.ThemeName = "Office2013Light";
            // 
            // radLabel34
            // 
            this.radLabel34.Location = new System.Drawing.Point(3, 463);
            this.radLabel34.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel34.Name = "radLabel34";
            this.radLabel34.Size = new System.Drawing.Size(47, 19);
            this.radLabel34.TabIndex = 163;
            this.radLabel34.Text = "Корпус";
            this.radLabel34.ThemeName = "Office2013Light";
            // 
            // DomLast
            // 
            this.DomLast.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.DomLast.Location = new System.Drawing.Point(166, 435);
            this.DomLast.Name = "DomLast";
            this.DomLast.Size = new System.Drawing.Size(33, 21);
            this.DomLast.TabIndex = 31;
            this.DomLast.ThemeName = "Office2013Light";
            // 
            // radLabel35
            // 
            this.radLabel35.Location = new System.Drawing.Point(3, 436);
            this.radLabel35.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel35.Name = "radLabel35";
            this.radLabel35.Size = new System.Drawing.Size(31, 19);
            this.radLabel35.TabIndex = 161;
            this.radLabel35.Text = "Дом";
            this.radLabel35.ThemeName = "Office2013Light";
            // 
            // addAbbrLast
            // 
            this.addAbbrLast.CheckState = System.Windows.Forms.CheckState.Checked;
            this.addAbbrLast.Location = new System.Drawing.Point(3, 491);
            this.addAbbrLast.Name = "addAbbrLast";
            this.addAbbrLast.Size = new System.Drawing.Size(284, 19);
            this.addAbbrLast.TabIndex = 36;
            this.addAbbrLast.Text = "Подставлять аббревиатуру Д., СТР., КОРП., КВ.";
            this.addAbbrLast.ThemeName = "Office2013Light";
            this.addAbbrLast.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            this.addAbbrLast.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.addAbbrLast_ToggleStateChanged);
            // 
            // KvartDeath
            // 
            this.KvartDeath.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KvartDeath.Location = new System.Drawing.Point(337, 223);
            this.KvartDeath.Name = "KvartDeath";
            this.KvartDeath.Size = new System.Drawing.Size(33, 21);
            this.KvartDeath.TabIndex = 17;
            this.KvartDeath.ThemeName = "Office2013Light";
            // 
            // radLabel32
            // 
            this.radLabel32.Location = new System.Drawing.Point(230, 224);
            this.radLabel32.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel32.Name = "radLabel32";
            this.radLabel32.Size = new System.Drawing.Size(60, 19);
            this.radLabel32.TabIndex = 158;
            this.radLabel32.Text = "Квартира";
            this.radLabel32.ThemeName = "Office2013Light";
            // 
            // KorpDeath
            // 
            this.KorpDeath.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.KorpDeath.Location = new System.Drawing.Point(167, 222);
            this.KorpDeath.Name = "KorpDeath";
            this.KorpDeath.Size = new System.Drawing.Size(33, 21);
            this.KorpDeath.TabIndex = 15;
            this.KorpDeath.ThemeName = "Office2013Light";
            // 
            // radLabel31
            // 
            this.radLabel31.Location = new System.Drawing.Point(3, 224);
            this.radLabel31.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel31.Name = "radLabel31";
            this.radLabel31.Size = new System.Drawing.Size(47, 19);
            this.radLabel31.TabIndex = 156;
            this.radLabel31.Text = "Корпус";
            this.radLabel31.ThemeName = "Office2013Light";
            // 
            // DomDeath
            // 
            this.DomDeath.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.DomDeath.Location = new System.Drawing.Point(166, 195);
            this.DomDeath.Name = "DomDeath";
            this.DomDeath.Size = new System.Drawing.Size(33, 21);
            this.DomDeath.TabIndex = 13;
            this.DomDeath.ThemeName = "Office2013Light";
            // 
            // radLabel30
            // 
            this.radLabel30.Location = new System.Drawing.Point(3, 197);
            this.radLabel30.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel30.Name = "radLabel30";
            this.radLabel30.Size = new System.Drawing.Size(31, 19);
            this.radLabel30.TabIndex = 154;
            this.radLabel30.Text = "Дом";
            this.radLabel30.ThemeName = "Office2013Light";
            // 
            // addAbbrDeath
            // 
            this.addAbbrDeath.CheckState = System.Windows.Forms.CheckState.Checked;
            this.addAbbrDeath.Location = new System.Drawing.Point(3, 251);
            this.addAbbrDeath.Name = "addAbbrDeath";
            this.addAbbrDeath.Size = new System.Drawing.Size(284, 19);
            this.addAbbrDeath.TabIndex = 19;
            this.addAbbrDeath.Text = "Подставлять аббревиатуру Д., СТР., КОРП., КВ.";
            this.addAbbrDeath.ThemeName = "Office2013Light";
            this.addAbbrDeath.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            this.addAbbrDeath.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.addAbbrDeath_ToggleStateChanged);
            // 
            // radLabel29
            // 
            this.radLabel29.Location = new System.Drawing.Point(374, 36);
            this.radLabel29.Name = "radLabel29";
            this.radLabel29.Size = new System.Drawing.Size(79, 19);
            this.radLabel29.TabIndex = 151;
            this.radLabel29.Text = "Сокращение";
            this.radLabel29.ThemeName = "Office2013Light";
            // 
            // radLabel25
            // 
            this.radLabel25.Location = new System.Drawing.Point(374, 275);
            this.radLabel25.Name = "radLabel25";
            this.radLabel25.Size = new System.Drawing.Size(79, 19);
            this.radLabel25.TabIndex = 150;
            this.radLabel25.Text = "Сокращение";
            this.radLabel25.ThemeName = "Office2013Light";
            // 
            // StreetLast_sokr
            // 
            this.StreetLast_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StreetLast_sokr.Location = new System.Drawing.Point(374, 408);
            this.StreetLast_sokr.Name = "StreetLast_sokr";
            this.StreetLast_sokr.Size = new System.Drawing.Size(72, 21);
            this.StreetLast_sokr.TabIndex = 29;
            this.StreetLast_sokr.ThemeName = "Office2013Light";
            // 
            // PunktLast_sokr
            // 
            this.PunktLast_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PunktLast_sokr.Location = new System.Drawing.Point(374, 381);
            this.PunktLast_sokr.Name = "PunktLast_sokr";
            this.PunktLast_sokr.Size = new System.Drawing.Size(72, 21);
            this.PunktLast_sokr.TabIndex = 27;
            this.PunktLast_sokr.ThemeName = "Office2013Light";
            // 
            // CityLast_sokr
            // 
            this.CityLast_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CityLast_sokr.Location = new System.Drawing.Point(374, 354);
            this.CityLast_sokr.Name = "CityLast_sokr";
            this.CityLast_sokr.Size = new System.Drawing.Size(72, 21);
            this.CityLast_sokr.TabIndex = 25;
            this.CityLast_sokr.ThemeName = "Office2013Light";
            // 
            // DistrLast_sokr
            // 
            this.DistrLast_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DistrLast_sokr.Location = new System.Drawing.Point(374, 327);
            this.DistrLast_sokr.Name = "DistrLast_sokr";
            this.DistrLast_sokr.Size = new System.Drawing.Size(72, 21);
            this.DistrLast_sokr.TabIndex = 23;
            this.DistrLast_sokr.ThemeName = "Office2013Light";
            // 
            // RegionLast_sokr
            // 
            this.RegionLast_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.RegionLast_sokr.Location = new System.Drawing.Point(374, 300);
            this.RegionLast_sokr.Name = "RegionLast_sokr";
            this.RegionLast_sokr.Size = new System.Drawing.Size(72, 21);
            this.RegionLast_sokr.TabIndex = 21;
            this.RegionLast_sokr.ThemeName = "Office2013Light";
            // 
            // StreetDeath_sokr
            // 
            this.StreetDeath_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StreetDeath_sokr.Location = new System.Drawing.Point(374, 169);
            this.StreetDeath_sokr.Name = "StreetDeath_sokr";
            this.StreetDeath_sokr.Size = new System.Drawing.Size(72, 21);
            this.StreetDeath_sokr.TabIndex = 11;
            this.StreetDeath_sokr.ThemeName = "Office2013Light";
            // 
            // PunktDeath_sokr
            // 
            this.PunktDeath_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PunktDeath_sokr.Location = new System.Drawing.Point(374, 142);
            this.PunktDeath_sokr.Name = "PunktDeath_sokr";
            this.PunktDeath_sokr.Size = new System.Drawing.Size(72, 21);
            this.PunktDeath_sokr.TabIndex = 9;
            this.PunktDeath_sokr.ThemeName = "Office2013Light";
            // 
            // CityDeath_sokr
            // 
            this.CityDeath_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CityDeath_sokr.Location = new System.Drawing.Point(374, 115);
            this.CityDeath_sokr.Name = "CityDeath_sokr";
            this.CityDeath_sokr.Size = new System.Drawing.Size(72, 21);
            this.CityDeath_sokr.TabIndex = 7;
            this.CityDeath_sokr.ThemeName = "Office2013Light";
            // 
            // DistrDeath_sokr
            // 
            this.DistrDeath_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DistrDeath_sokr.Location = new System.Drawing.Point(374, 88);
            this.DistrDeath_sokr.Name = "DistrDeath_sokr";
            this.DistrDeath_sokr.Size = new System.Drawing.Size(72, 21);
            this.DistrDeath_sokr.TabIndex = 5;
            this.DistrDeath_sokr.ThemeName = "Office2013Light";
            // 
            // RegionDeath_sokr
            // 
            this.RegionDeath_sokr.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.RegionDeath_sokr.Location = new System.Drawing.Point(374, 61);
            this.RegionDeath_sokr.Name = "RegionDeath_sokr";
            this.RegionDeath_sokr.Size = new System.Drawing.Size(72, 21);
            this.RegionDeath_sokr.TabIndex = 3;
            this.RegionDeath_sokr.ThemeName = "Office2013Light";
            // 
            // StreetLast
            // 
            this.StreetLast.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StreetLast.Location = new System.Drawing.Point(119, 408);
            this.StreetLast.Name = "StreetLast";
            this.StreetLast.Size = new System.Drawing.Size(252, 21);
            this.StreetLast.TabIndex = 28;
            this.StreetLast.ThemeName = "Office2013Light";
            // 
            // radLabel22
            // 
            this.radLabel22.Location = new System.Drawing.Point(3, 408);
            this.radLabel22.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel22.Name = "radLabel22";
            this.radLabel22.Size = new System.Drawing.Size(41, 19);
            this.radLabel22.TabIndex = 139;
            this.radLabel22.Text = "Улица";
            this.radLabel22.ThemeName = "Office2013Light";
            // 
            // CityLast
            // 
            this.CityLast.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CityLast.Location = new System.Drawing.Point(119, 354);
            this.CityLast.Name = "CityLast";
            this.CityLast.Size = new System.Drawing.Size(252, 21);
            this.CityLast.TabIndex = 24;
            this.CityLast.ThemeName = "Office2013Light";
            // 
            // radLabel21
            // 
            this.radLabel21.Location = new System.Drawing.Point(3, 354);
            this.radLabel21.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel21.Name = "radLabel21";
            this.radLabel21.Size = new System.Drawing.Size(41, 19);
            this.radLabel21.TabIndex = 137;
            this.radLabel21.Text = "Город";
            this.radLabel21.ThemeName = "Office2013Light";
            // 
            // StreetDeath
            // 
            this.StreetDeath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.StreetDeath.Location = new System.Drawing.Point(119, 169);
            this.StreetDeath.Name = "StreetDeath";
            this.StreetDeath.Size = new System.Drawing.Size(252, 21);
            this.StreetDeath.TabIndex = 10;
            this.StreetDeath.ThemeName = "Office2013Light";
            // 
            // radLabel20
            // 
            this.radLabel20.Location = new System.Drawing.Point(3, 169);
            this.radLabel20.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel20.Name = "radLabel20";
            this.radLabel20.Size = new System.Drawing.Size(41, 19);
            this.radLabel20.TabIndex = 135;
            this.radLabel20.Text = "Улица";
            this.radLabel20.ThemeName = "Office2013Light";
            // 
            // PunktDeath
            // 
            this.PunktDeath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PunktDeath.Location = new System.Drawing.Point(119, 142);
            this.PunktDeath.Name = "PunktDeath";
            this.PunktDeath.Size = new System.Drawing.Size(252, 21);
            this.PunktDeath.TabIndex = 8;
            this.PunktDeath.ThemeName = "Office2013Light";
            // 
            // radLabel19
            // 
            this.radLabel19.Location = new System.Drawing.Point(3, 142);
            this.radLabel19.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel19.Name = "radLabel19";
            this.radLabel19.Size = new System.Drawing.Size(112, 19);
            this.radLabel19.TabIndex = 133;
            this.radLabel19.Text = "Населенный пункт";
            this.radLabel19.ThemeName = "Office2013Light";
            // 
            // radLabel48
            // 
            this.radLabel48.Location = new System.Drawing.Point(421, 25);
            this.radLabel48.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.radLabel48.Name = "radLabel48";
            this.radLabel48.Size = new System.Drawing.Size(25, 19);
            this.radLabel48.TabIndex = 10;
            this.radLabel48.Text = "год";
            this.radLabel48.ThemeName = "Office2013Light";
            this.radLabel48.Visible = false;
            // 
            // dYearOs_TextBox
            // 
            this.dYearOs_TextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.dYearOs_TextBox.Enabled = false;
            this.dYearOs_TextBox.Location = new System.Drawing.Point(374, 23);
            this.dYearOs_TextBox.MaxLength = 4;
            this.dYearOs_TextBox.Name = "dYearOs_TextBox";
            this.dYearOs_TextBox.Size = new System.Drawing.Size(31, 21);
            this.dYearOs_TextBox.TabIndex = 8;
            this.dYearOs_TextBox.ThemeName = "Office2013Light";
            this.dYearOs_TextBox.Visible = false;
            // 
            // dYearOs_SpinEditor
            // 
            this.dYearOs_SpinEditor.Enabled = false;
            this.dYearOs_SpinEditor.Location = new System.Drawing.Point(374, 23);
            this.dYearOs_SpinEditor.Maximum = new decimal(new int[] {
            2100,
            0,
            0,
            0});
            this.dYearOs_SpinEditor.Name = "dYearOs_SpinEditor";
            this.dYearOs_SpinEditor.Size = new System.Drawing.Size(44, 21);
            this.dYearOs_SpinEditor.TabIndex = 131;
            this.dYearOs_SpinEditor.TabStop = false;
            this.dYearOs_SpinEditor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.dYearOs_SpinEditor.ThemeName = "Office2013Light";
            this.dYearOs_SpinEditor.Visible = false;
            // 
            // radLabel43
            // 
            this.radLabel43.Location = new System.Drawing.Point(330, 25);
            this.radLabel43.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.radLabel43.Name = "radLabel43";
            this.radLabel43.Size = new System.Drawing.Size(41, 19);
            this.radLabel43.TabIndex = 7;
            this.radLabel43.Text = "месяц";
            this.radLabel43.ThemeName = "Office2013Light";
            this.radLabel43.Visible = false;
            // 
            // dMonthOs_TextBox
            // 
            this.dMonthOs_TextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.dMonthOs_TextBox.Enabled = false;
            this.dMonthOs_TextBox.Location = new System.Drawing.Point(289, 23);
            this.dMonthOs_TextBox.MaxLength = 2;
            this.dMonthOs_TextBox.Name = "dMonthOs_TextBox";
            this.dMonthOs_TextBox.Size = new System.Drawing.Size(23, 21);
            this.dMonthOs_TextBox.TabIndex = 6;
            this.dMonthOs_TextBox.ThemeName = "Office2013Light";
            this.dMonthOs_TextBox.Visible = false;
            // 
            // dMonthOs_SpinEditor
            // 
            this.dMonthOs_SpinEditor.Enabled = false;
            this.dMonthOs_SpinEditor.Location = new System.Drawing.Point(289, 23);
            this.dMonthOs_SpinEditor.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.dMonthOs_SpinEditor.Name = "dMonthOs_SpinEditor";
            this.dMonthOs_SpinEditor.Size = new System.Drawing.Size(36, 21);
            this.dMonthOs_SpinEditor.TabIndex = 129;
            this.dMonthOs_SpinEditor.TabStop = false;
            this.dMonthOs_SpinEditor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.dMonthOs_SpinEditor.ThemeName = "Office2013Light";
            this.dMonthOs_SpinEditor.Visible = false;
            // 
            // radLabel44
            // 
            this.radLabel44.Location = new System.Drawing.Point(253, 26);
            this.radLabel44.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.radLabel44.Name = "radLabel44";
            this.radLabel44.Size = new System.Drawing.Size(33, 19);
            this.radLabel44.TabIndex = 5;
            this.radLabel44.Text = "день";
            this.radLabel44.ThemeName = "Office2013Light";
            this.radLabel44.Visible = false;
            // 
            // dDayOs_TextBox
            // 
            this.dDayOs_TextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.dDayOs_TextBox.Enabled = false;
            this.dDayOs_TextBox.Location = new System.Drawing.Point(214, 24);
            this.dDayOs_TextBox.MaxLength = 2;
            this.dDayOs_TextBox.Name = "dDayOs_TextBox";
            this.dDayOs_TextBox.Size = new System.Drawing.Size(23, 21);
            this.dDayOs_TextBox.TabIndex = 4;
            this.dDayOs_TextBox.ThemeName = "Office2013Light";
            this.dDayOs_TextBox.Visible = false;
            // 
            // dDayOs_SpinEditor
            // 
            this.dDayOs_SpinEditor.Enabled = false;
            this.dDayOs_SpinEditor.Location = new System.Drawing.Point(216, 24);
            this.dDayOs_SpinEditor.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.dDayOs_SpinEditor.Name = "dDayOs_SpinEditor";
            this.dDayOs_SpinEditor.Size = new System.Drawing.Size(36, 21);
            this.dDayOs_SpinEditor.TabIndex = 127;
            this.dDayOs_SpinEditor.TabStop = false;
            this.dDayOs_SpinEditor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right;
            this.dDayOs_SpinEditor.ThemeName = "Office2013Light";
            this.dDayOs_SpinEditor.Visible = false;
            // 
            // dDateOs_CheckBox
            // 
            this.dDateOs_CheckBox.Location = new System.Drawing.Point(214, -1);
            this.dDateOs_CheckBox.Name = "dDateOs_CheckBox";
            this.dDateOs_CheckBox.Size = new System.Drawing.Size(156, 19);
            this.dDateOs_CheckBox.TabIndex = 0;
            this.dDateOs_CheckBox.Text = "Особая Дата рождения";
            this.dDateOs_CheckBox.ThemeName = "Office2013Light";
            this.dDateOs_CheckBox.Visible = false;
            // 
            // PunktLast
            // 
            this.PunktLast.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.PunktLast.Location = new System.Drawing.Point(119, 381);
            this.PunktLast.Name = "PunktLast";
            this.PunktLast.Size = new System.Drawing.Size(252, 21);
            this.PunktLast.TabIndex = 26;
            this.PunktLast.ThemeName = "Office2013Light";
            // 
            // DistrLast
            // 
            this.DistrLast.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DistrLast.Location = new System.Drawing.Point(119, 327);
            this.DistrLast.Name = "DistrLast";
            this.DistrLast.Size = new System.Drawing.Size(252, 21);
            this.DistrLast.TabIndex = 22;
            this.DistrLast.ThemeName = "Office2013Light";
            // 
            // RegionLast
            // 
            this.RegionLast.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.RegionLast.Location = new System.Drawing.Point(119, 300);
            this.RegionLast.Name = "RegionLast";
            this.RegionLast.Size = new System.Drawing.Size(252, 21);
            this.RegionLast.TabIndex = 20;
            this.RegionLast.ThemeName = "Office2013Light";
            // 
            // radLabel39
            // 
            this.radLabel39.Location = new System.Drawing.Point(3, 381);
            this.radLabel39.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel39.Name = "radLabel39";
            this.radLabel39.Size = new System.Drawing.Size(112, 19);
            this.radLabel39.TabIndex = 119;
            this.radLabel39.Text = "Населенный пункт";
            this.radLabel39.ThemeName = "Office2013Light";
            // 
            // radLabel40
            // 
            this.radLabel40.Location = new System.Drawing.Point(3, 327);
            this.radLabel40.Name = "radLabel40";
            this.radLabel40.Size = new System.Drawing.Size(41, 19);
            this.radLabel40.TabIndex = 120;
            this.radLabel40.Text = "Район";
            this.radLabel40.ThemeName = "Office2013Light";
            // 
            // radLabel41
            // 
            this.radLabel41.Location = new System.Drawing.Point(3, 300);
            this.radLabel41.Name = "radLabel41";
            this.radLabel41.Size = new System.Drawing.Size(96, 19);
            this.radLabel41.TabIndex = 121;
            this.radLabel41.Text = "Регион, область";
            this.radLabel41.ThemeName = "Office2013Light";
            // 
            // radLabel23
            // 
            this.radLabel23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.radLabel23.Location = new System.Drawing.Point(3, 275);
            this.radLabel23.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.radLabel23.Name = "radLabel23";
            this.radLabel23.Size = new System.Drawing.Size(185, 19);
            this.radLabel23.TabIndex = 112;
            this.radLabel23.Text = "Последнее место жительства";
            this.radLabel23.ThemeName = "Office2013Light";
            // 
            // DateDeath_MaskedEditBox
            // 
            this.DateDeath_MaskedEditBox.Location = new System.Drawing.Point(119, 9);
            this.DateDeath_MaskedEditBox.Mask = "00/00/0000";
            this.DateDeath_MaskedEditBox.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.DateDeath_MaskedEditBox.Name = "DateDeath_MaskedEditBox";
            this.DateDeath_MaskedEditBox.NullText = "__.__.____";
            this.DateDeath_MaskedEditBox.Size = new System.Drawing.Size(64, 21);
            this.DateDeath_MaskedEditBox.TabIndex = 0;
            this.DateDeath_MaskedEditBox.TabStop = false;
            this.DateDeath_MaskedEditBox.Text = "__.__.____";
            this.DateDeath_MaskedEditBox.ThemeName = "Office2013Light";
            this.DateDeath_MaskedEditBox.Leave += new System.EventHandler(this.DateDeath_MaskedEditBox_Leave);
            // 
            // radLabel49
            // 
            this.radLabel49.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.radLabel49.Location = new System.Drawing.Point(3, 11);
            this.radLabel49.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel49.Name = "radLabel49";
            this.radLabel49.Size = new System.Drawing.Size(82, 19);
            this.radLabel49.TabIndex = 98;
            this.radLabel49.Text = "Дата смерти";
            this.radLabel49.ThemeName = "Office2013Light";
            // 
            // DateDeath
            // 
            this.DateDeath.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateDeath.Location = new System.Drawing.Point(119, 9);
            this.DateDeath.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.DateDeath.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateDeath.Name = "DateDeath";
            this.DateDeath.NullDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateDeath.Size = new System.Drawing.Size(85, 21);
            this.DateDeath.TabIndex = 1;
            this.DateDeath.TabStop = false;
            this.DateDeath.ThemeName = "Office2013Light";
            this.DateDeath.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DateDeath.ValueChanged += new System.EventHandler(this.DateDeath_ValueChanged);
            // 
            // CityDeath
            // 
            this.CityDeath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CityDeath.Location = new System.Drawing.Point(119, 115);
            this.CityDeath.Name = "CityDeath";
            this.CityDeath.Size = new System.Drawing.Size(252, 21);
            this.CityDeath.TabIndex = 6;
            this.CityDeath.ThemeName = "Office2013Light";
            // 
            // DistrDeath
            // 
            this.DistrDeath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.DistrDeath.Location = new System.Drawing.Point(119, 88);
            this.DistrDeath.Name = "DistrDeath";
            this.DistrDeath.Size = new System.Drawing.Size(252, 21);
            this.DistrDeath.TabIndex = 4;
            this.DistrDeath.ThemeName = "Office2013Light";
            // 
            // RegionDeath
            // 
            this.RegionDeath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.RegionDeath.Location = new System.Drawing.Point(119, 61);
            this.RegionDeath.Name = "RegionDeath";
            this.RegionDeath.Size = new System.Drawing.Size(252, 21);
            this.RegionDeath.TabIndex = 2;
            this.RegionDeath.ThemeName = "Office2013Light";
            // 
            // radLabel26
            // 
            this.radLabel26.Location = new System.Drawing.Point(3, 115);
            this.radLabel26.Margin = new System.Windows.Forms.Padding(3, 9, 3, 3);
            this.radLabel26.Name = "radLabel26";
            this.radLabel26.Size = new System.Drawing.Size(41, 19);
            this.radLabel26.TabIndex = 92;
            this.radLabel26.Text = "Город";
            this.radLabel26.ThemeName = "Office2013Light";
            // 
            // radLabel27
            // 
            this.radLabel27.Location = new System.Drawing.Point(3, 88);
            this.radLabel27.Name = "radLabel27";
            this.radLabel27.Size = new System.Drawing.Size(41, 19);
            this.radLabel27.TabIndex = 93;
            this.radLabel27.Text = "Район";
            this.radLabel27.ThemeName = "Office2013Light";
            // 
            // radLabel28
            // 
            this.radLabel28.Location = new System.Drawing.Point(3, 61);
            this.radLabel28.Name = "radLabel28";
            this.radLabel28.Size = new System.Drawing.Size(96, 19);
            this.radLabel28.TabIndex = 94;
            this.radLabel28.Text = "Регион, область";
            this.radLabel28.ThemeName = "Office2013Light";
            // 
            // radLabel24
            // 
            this.radLabel24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.radLabel24.Location = new System.Drawing.Point(3, 36);
            this.radLabel24.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.radLabel24.Name = "radLabel24";
            this.radLabel24.Size = new System.Drawing.Size(91, 19);
            this.radLabel24.TabIndex = 88;
            this.radLabel24.Text = "Место смерти";
            this.radLabel24.ThemeName = "Office2013Light";
            // 
            // closeBtn
            // 
            this.closeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBtn.Location = new System.Drawing.Point(370, 570);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(110, 24);
            this.closeBtn.TabIndex = 2;
            this.closeBtn.Text = "Отмена";
            this.closeBtn.ThemeName = "Office2013Light";
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.saveBtn.Location = new System.Drawing.Point(242, 570);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(3, 6, 3, 3);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(110, 24);
            this.saveBtn.TabIndex = 1;
            this.saveBtn.Text = "Сохранить";
            this.saveBtn.ThemeName = "Office2013Light";
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // StroenLast_sokr
            // 
            this.StroenLast_sokr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.StroenLast_sokr.Enabled = false;
            this.StroenLast_sokr.Location = new System.Drawing.Point(288, 435);
            this.StroenLast_sokr.Name = "StroenLast_sokr";
            this.StroenLast_sokr.Size = new System.Drawing.Size(43, 21);
            this.StroenLast_sokr.TabIndex = 169;
            this.StroenLast_sokr.Text = "СТР.";
            this.StroenLast_sokr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.StroenLast_sokr.ThemeName = "Office2013Light";
            // 
            // StroenLast
            // 
            this.StroenLast.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.StroenLast.Location = new System.Drawing.Point(337, 435);
            this.StroenLast.Name = "StroenLast";
            this.StroenLast.Size = new System.Drawing.Size(33, 21);
            this.StroenLast.TabIndex = 170;
            this.StroenLast.ThemeName = "Office2013Light";
            // 
            // radLabel37
            // 
            this.radLabel37.Location = new System.Drawing.Point(230, 436);
            this.radLabel37.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.radLabel37.Name = "radLabel37";
            this.radLabel37.Size = new System.Drawing.Size(60, 19);
            this.radLabel37.TabIndex = 171;
            this.radLabel37.Text = "Квартира";
            this.radLabel37.ThemeName = "Office2013Light";
            // 
            // Death_Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 606);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.radPageView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Death_Edit";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Редактирование информации об умершем";
            this.ThemeName = "Office2013Light";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Death_Edit_FormClosing);
            this.Load += new System.EventHandler(this.Death_Edit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.radPageView1)).EndInit();
            this.radPageView1.ResumeLayout(false);
            this.radPageViewPage1.ResumeLayout(false);
            this.radPageViewPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CountryBirth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktBirth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrBirth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionBirth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_OrgZags)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_Num)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_Date_MaskedEditBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Akt_Date)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Type_PlaceBirth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YearOs_TextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YearOs_SpinEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MonthOs_TextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MonthOs_SpinEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DayOs_TextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DayOs_SpinEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateOs_CheckBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateBirth_MaskedEditBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SexFRadioButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SexMRadioButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FirstName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LastName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MiddleName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateBirth)).EndInit();
            this.radPageViewPage2.ResumeLayout(false);
            this.radPageViewPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.StroenDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StroenDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addAbbrLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KvartDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KorpDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DomDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addAbbrDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionDeath_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StreetDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dYearOs_TextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dYearOs_SpinEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMonthOs_TextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dMonthOs_SpinEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dDayOs_TextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dDayOs_SpinEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dDateOs_CheckBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PunktLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDeath_MaskedEditBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CityDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DistrDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RegionDeath)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StroenLast_sokr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StroenLast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadPageView radPageView1;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage1;
        private Telerik.WinControls.UI.RadPageViewPage radPageViewPage2;
        private Telerik.WinControls.UI.RadButton closeBtn;
        private Telerik.WinControls.UI.RadButton saveBtn;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private Telerik.WinControls.UI.RadTextBox YearOs_TextBox;
        private Telerik.WinControls.UI.RadSpinEditor YearOs_SpinEditor;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadTextBox MonthOs_TextBox;
        private Telerik.WinControls.UI.RadSpinEditor MonthOs_SpinEditor;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadTextBox DayOs_TextBox;
        private Telerik.WinControls.UI.RadSpinEditor DayOs_SpinEditor;
        private Telerik.WinControls.UI.RadCheckBox DateOs_CheckBox;
        private Telerik.WinControls.UI.RadMaskedEditBox DateBirth_MaskedEditBox;
        private Telerik.WinControls.UI.RadRadioButton SexFRadioButton;
        private Telerik.WinControls.UI.RadRadioButton SexMRadioButton;
        private Telerik.WinControls.UI.RadTextBox FirstName;
        private Telerik.WinControls.UI.RadTextBox LastName;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadTextBox MiddleName;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        public Telerik.WinControls.UI.RadDateTimePicker DateBirth;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel radLabel17;
        private Telerik.WinControls.UI.RadLabel radLabel14;
        private Telerik.WinControls.UI.RadLabel radLabel15;
        private Telerik.WinControls.UI.RadLabel radLabel16;
        private Telerik.WinControls.UI.RadDropDownList Type_PlaceBirth;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadTextBox Akt_OrgZags;
        private Telerik.WinControls.UI.RadLabel radLabel18;
        private Telerik.WinControls.UI.RadTextBox Akt_Num;
        private Telerik.WinControls.UI.RadLabel radLabel12;
        private Telerik.WinControls.UI.RadMaskedEditBox Akt_Date_MaskedEditBox;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        public Telerik.WinControls.UI.RadDateTimePicker Akt_Date;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel24;
        private Telerik.WinControls.UI.RadDropDownList RegionBirth;
        private Telerik.WinControls.UI.RadDropDownList DistrBirth;
        private Telerik.WinControls.UI.RadDropDownList PunktBirth;
        private Telerik.WinControls.UI.RadDropDownList CountryBirth;
        private Telerik.WinControls.UI.RadDropDownList CityDeath;
        private Telerik.WinControls.UI.RadDropDownList DistrDeath;
        private Telerik.WinControls.UI.RadDropDownList RegionDeath;
        private Telerik.WinControls.UI.RadLabel radLabel26;
        private Telerik.WinControls.UI.RadLabel radLabel27;
        private Telerik.WinControls.UI.RadLabel radLabel28;
        private Telerik.WinControls.UI.RadDropDownList PunktLast;
        private Telerik.WinControls.UI.RadDropDownList DistrLast;
        private Telerik.WinControls.UI.RadDropDownList RegionLast;
        private Telerik.WinControls.UI.RadLabel radLabel39;
        private Telerik.WinControls.UI.RadLabel radLabel40;
        private Telerik.WinControls.UI.RadLabel radLabel41;
        private Telerik.WinControls.UI.RadLabel radLabel23;
        private Telerik.WinControls.UI.RadMaskedEditBox DateDeath_MaskedEditBox;
        private Telerik.WinControls.UI.RadLabel radLabel49;
        public Telerik.WinControls.UI.RadDateTimePicker DateDeath;
        private Telerik.WinControls.UI.RadLabel radLabel48;
        private Telerik.WinControls.UI.RadTextBox dYearOs_TextBox;
        private Telerik.WinControls.UI.RadSpinEditor dYearOs_SpinEditor;
        private Telerik.WinControls.UI.RadLabel radLabel43;
        private Telerik.WinControls.UI.RadTextBox dMonthOs_TextBox;
        private Telerik.WinControls.UI.RadSpinEditor dMonthOs_SpinEditor;
        private Telerik.WinControls.UI.RadLabel radLabel44;
        private Telerik.WinControls.UI.RadTextBox dDayOs_TextBox;
        private Telerik.WinControls.UI.RadSpinEditor dDayOs_SpinEditor;
        private Telerik.WinControls.UI.RadCheckBox dDateOs_CheckBox;
        private Telerik.WinControls.UI.RadDropDownList StreetDeath;
        private Telerik.WinControls.UI.RadLabel radLabel20;
        private Telerik.WinControls.UI.RadDropDownList PunktDeath;
        private Telerik.WinControls.UI.RadLabel radLabel19;
        private Telerik.WinControls.UI.RadDropDownList StreetLast;
        private Telerik.WinControls.UI.RadLabel radLabel22;
        private Telerik.WinControls.UI.RadDropDownList CityLast;
        private Telerik.WinControls.UI.RadLabel radLabel21;
        private Telerik.WinControls.UI.RadLabel radLabel29;
        private Telerik.WinControls.UI.RadLabel radLabel25;
        private Telerik.WinControls.UI.RadDropDownList StreetLast_sokr;
        private Telerik.WinControls.UI.RadDropDownList PunktLast_sokr;
        private Telerik.WinControls.UI.RadDropDownList CityLast_sokr;
        private Telerik.WinControls.UI.RadDropDownList DistrLast_sokr;
        private Telerik.WinControls.UI.RadDropDownList RegionLast_sokr;
        private Telerik.WinControls.UI.RadDropDownList StreetDeath_sokr;
        private Telerik.WinControls.UI.RadDropDownList PunktDeath_sokr;
        private Telerik.WinControls.UI.RadDropDownList CityDeath_sokr;
        private Telerik.WinControls.UI.RadDropDownList DistrDeath_sokr;
        private Telerik.WinControls.UI.RadDropDownList RegionDeath_sokr;
        private Telerik.WinControls.UI.RadCheckBox addAbbrDeath;
        private Telerik.WinControls.UI.RadTextBox KvartDeath;
        private Telerik.WinControls.UI.RadLabel radLabel32;
        private Telerik.WinControls.UI.RadTextBox KorpDeath;
        private Telerik.WinControls.UI.RadLabel radLabel31;
        private Telerik.WinControls.UI.RadTextBox DomDeath;
        private Telerik.WinControls.UI.RadLabel radLabel30;
        private Telerik.WinControls.UI.RadTextBox KvartLast;
        private Telerik.WinControls.UI.RadLabel radLabel33;
        private Telerik.WinControls.UI.RadTextBox KorpLast;
        private Telerik.WinControls.UI.RadLabel radLabel34;
        private Telerik.WinControls.UI.RadTextBox DomLast;
        private Telerik.WinControls.UI.RadLabel radLabel35;
        private Telerik.WinControls.UI.RadCheckBox addAbbrLast;
        private Telerik.WinControls.UI.RadTextBox KvartDeath_sokr;
        private Telerik.WinControls.UI.RadTextBox KorpDeath_sokr;
        private Telerik.WinControls.UI.RadTextBox DomDeath_sokr;
        private Telerik.WinControls.UI.RadTextBox KvartLast_sokr;
        private Telerik.WinControls.UI.RadTextBox KorpLast_sokr;
        private Telerik.WinControls.UI.RadTextBox DomLast_sokr;
        private Telerik.WinControls.UI.RadTextBox StroenDeath_sokr;
        private Telerik.WinControls.UI.RadTextBox StroenDeath;
        private Telerik.WinControls.UI.RadLabel radLabel36;
        private Telerik.WinControls.UI.RadTextBox StroenLast_sokr;
        private Telerik.WinControls.UI.RadTextBox StroenLast;
        private Telerik.WinControls.UI.RadLabel radLabel37;

    }
}
