﻿namespace PU.ZAGS.Zags_Death
{
    partial class CreateXmlPack_Death
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.remainChkbox = new Telerik.WinControls.UI.RadCheckBox();
            this.FromTextBox = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.btnSave = new Telerik.WinControls.UI.RadButton();
            this.btnClose = new Telerik.WinControls.UI.RadButton();
            this.pathBrowser = new Telerik.WinControls.UI.RadBrowseEditor();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.ToTextBox = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.codePoluchTextBox = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.codeOtpravTextBox = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.remainChkbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FromTextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pathBrowser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToTextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codePoluchTextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeOtpravTextBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // remainChkbox
            // 
            this.remainChkbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.remainChkbox.Location = new System.Drawing.Point(354, 64);
            this.remainChkbox.Name = "remainChkbox";
            this.remainChkbox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.remainChkbox.Size = new System.Drawing.Size(106, 18);
            this.remainChkbox.TabIndex = 1;
            this.remainChkbox.Text = "запомнить путь";
            this.remainChkbox.ThemeName = "Office2013Light";
            this.remainChkbox.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            // 
            // FromTextBox
            // 
            this.FromTextBox.HideSelection = false;
            this.FromTextBox.Location = new System.Drawing.Point(113, 94);
            this.FromTextBox.MaxLength = 0;
            this.FromTextBox.Name = "FromTextBox";
            this.FromTextBox.Size = new System.Drawing.Size(347, 21);
            this.FromTextBox.TabIndex = 2;
            this.FromTextBox.ThemeName = "Office2013Light";
            // 
            // radLabel6
            // 
            this.radLabel6.Location = new System.Drawing.Point(12, 95);
            this.radLabel6.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(76, 19);
            this.radLabel6.TabIndex = 49;
            this.radLabel6.Text = "Составитель";
            this.radLabel6.ThemeName = "Office2013Light";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(234, 224);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 25, 3, 3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(110, 24);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Сохранить";
            this.btnSave.ThemeName = "Office2013Light";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(350, 224);
            this.btnClose.Margin = new System.Windows.Forms.Padding(3, 25, 3, 3);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(110, 24);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Закрыть";
            this.btnClose.ThemeName = "Office2013Light";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pathBrowser
            // 
            this.pathBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pathBrowser.DialogType = Telerik.WinControls.UI.BrowseEditorDialogType.FolderBrowseDialog;
            this.pathBrowser.Location = new System.Drawing.Point(12, 37);
            this.pathBrowser.Name = "pathBrowser";
            this.pathBrowser.Size = new System.Drawing.Size(448, 21);
            this.pathBrowser.TabIndex = 0;
            this.pathBrowser.ThemeName = "Office2013Light";
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(12, 12);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(234, 19);
            this.radLabel1.TabIndex = 48;
            this.radLabel1.Text = "Местоположение выгружаемых файлов";
            this.radLabel1.ThemeName = "Office2013Light";
            // 
            // ToTextBox
            // 
            this.ToTextBox.HideSelection = false;
            this.ToTextBox.Location = new System.Drawing.Point(113, 126);
            this.ToTextBox.MaxLength = 0;
            this.ToTextBox.Name = "ToTextBox";
            this.ToTextBox.Size = new System.Drawing.Size(347, 21);
            this.ToTextBox.TabIndex = 3;
            this.ToTextBox.ThemeName = "Office2013Light";
            // 
            // radLabel2
            // 
            this.radLabel2.Location = new System.Drawing.Point(12, 127);
            this.radLabel2.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(73, 19);
            this.radLabel2.TabIndex = 52;
            this.radLabel2.Text = "Получатель";
            this.radLabel2.ThemeName = "Office2013Light";
            // 
            // codePoluchTextBox
            // 
            this.codePoluchTextBox.HideSelection = false;
            this.codePoluchTextBox.Location = new System.Drawing.Point(113, 158);
            this.codePoluchTextBox.MaxLength = 0;
            this.codePoluchTextBox.Name = "codePoluchTextBox";
            this.codePoluchTextBox.Size = new System.Drawing.Size(92, 21);
            this.codePoluchTextBox.TabIndex = 4;
            this.codePoluchTextBox.ThemeName = "Office2013Light";
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(12, 159);
            this.radLabel3.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(95, 19);
            this.radLabel3.TabIndex = 54;
            this.radLabel3.Text = "Код получателя";
            this.radLabel3.ThemeName = "Office2013Light";
            // 
            // codeOtpravTextBox
            // 
            this.codeOtpravTextBox.HideSelection = false;
            this.codeOtpravTextBox.Location = new System.Drawing.Point(113, 190);
            this.codeOtpravTextBox.MaxLength = 0;
            this.codeOtpravTextBox.Name = "codeOtpravTextBox";
            this.codeOtpravTextBox.Size = new System.Drawing.Size(92, 21);
            this.codeOtpravTextBox.TabIndex = 5;
            this.codeOtpravTextBox.ThemeName = "Office2013Light";
            // 
            // radLabel4
            // 
            this.radLabel4.Location = new System.Drawing.Point(12, 191);
            this.radLabel4.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(102, 19);
            this.radLabel4.TabIndex = 56;
            this.radLabel4.Text = "Код отправителя";
            this.radLabel4.ThemeName = "Office2013Light";
            // 
            // CreateXmlPack_Death
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 260);
            this.Controls.Add(this.codeOtpravTextBox);
            this.Controls.Add(this.radLabel4);
            this.Controls.Add(this.codePoluchTextBox);
            this.Controls.Add(this.radLabel3);
            this.Controls.Add(this.ToTextBox);
            this.Controls.Add(this.radLabel2);
            this.Controls.Add(this.remainChkbox);
            this.Controls.Add(this.FromTextBox);
            this.Controls.Add(this.radLabel6);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pathBrowser);
            this.Controls.Add(this.radLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "CreateXmlPack_Death";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Запись в XML-файл сведений об умерших";
            this.ThemeName = "Office2013Light";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateXmlPack_Death_FormClosing);
            this.Load += new System.EventHandler(this.CreateXmlPack_Death_Load);
            ((System.ComponentModel.ISupportInitialize)(this.remainChkbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FromTextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pathBrowser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToTextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codePoluchTextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeOtpravTextBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadCheckBox remainChkbox;
        private Telerik.WinControls.UI.RadTextBox FromTextBox;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadButton btnSave;
        private Telerik.WinControls.UI.RadButton btnClose;
        private Telerik.WinControls.UI.RadBrowseEditor pathBrowser;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadTextBox ToTextBox;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadTextBox codePoluchTextBox;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadTextBox codeOtpravTextBox;
        private Telerik.WinControls.UI.RadLabel radLabel4;
    }
}
