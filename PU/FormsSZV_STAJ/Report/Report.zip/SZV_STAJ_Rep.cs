namespace PU.FormsSZV_STAJ.Report
{
    using System;
    using System.ComponentModel;
    using System.Drawing;
    using System.Windows.Forms;
    using Telerik.Reporting;
    using Telerik.Reporting.Drawing;

    /// <summary>
    /// Summary description for SZV_STAJ_Rep.
    /// </summary>
    public partial class SZV_STAJ_Rep : Telerik.Reporting.Report
    {
        public SZV_STAJ_Rep()
        {
            //
            // Required for telerik Reporting designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }
    }
}