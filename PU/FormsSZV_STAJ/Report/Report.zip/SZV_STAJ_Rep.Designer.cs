namespace PU.FormsSZV_STAJ.Report
{
    partial class SZV_STAJ_Rep
    {
        #region Component Designer generated code
        /// <summary>
        /// Required method for telerik Reporting designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.Reporting.TableGroup tableGroup1 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup2 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup3 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup4 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup5 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup6 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup7 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup8 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup9 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup10 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup11 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup12 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup13 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup14 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup15 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup16 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup17 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup18 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup19 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup20 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup21 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup22 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup23 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup24 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup25 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup26 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup27 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup28 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup29 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup30 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup31 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup32 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup33 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup34 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup35 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup36 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup37 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup38 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup39 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup40 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup41 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup42 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup43 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup44 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup45 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup46 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup47 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup48 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup49 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup50 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup51 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup52 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup53 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup54 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup55 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup56 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup57 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.TableGroup tableGroup58 = new Telerik.Reporting.TableGroup();
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.textBox85 = new Telerik.Reporting.TextBox();
            this.textBox24 = new Telerik.Reporting.TextBox();
            this.textBox22 = new Telerik.Reporting.TextBox();
            this.textBox20 = new Telerik.Reporting.TextBox();
            this.textBox18 = new Telerik.Reporting.TextBox();
            this.textBox27 = new Telerik.Reporting.TextBox();
            this.textBox28 = new Telerik.Reporting.TextBox();
            this.textBox87 = new Telerik.Reporting.TextBox();
            this.textBox91 = new Telerik.Reporting.TextBox();
            this.textBox93 = new Telerik.Reporting.TextBox();
            this.textBox106 = new Telerik.Reporting.TextBox();
            this.textBox107 = new Telerik.Reporting.TextBox();
            this.textBox95 = new Telerik.Reporting.TextBox();
            this.textBox108 = new Telerik.Reporting.TextBox();
            this.textBox109 = new Telerik.Reporting.TextBox();
            this.textBox99 = new Telerik.Reporting.TextBox();
            this.textBox29 = new Telerik.Reporting.TextBox();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.textBox83 = new Telerik.Reporting.TextBox();
            this.RegNum = new Telerik.Reporting.TextBox();
            this.textBox12 = new Telerik.Reporting.TextBox();
            this.textBox9 = new Telerik.Reporting.TextBox();
            this.INN = new Telerik.Reporting.TextBox();
            this.textBox26 = new Telerik.Reporting.TextBox();
            this.textBox1 = new Telerik.Reporting.TextBox();
            this.KPP = new Telerik.Reporting.TextBox();
            this.textBox2 = new Telerik.Reporting.TextBox();
            this.detail = new Telerik.Reporting.DetailSection();
            this.textBox10 = new Telerik.Reporting.TextBox();
            this.KPP2 = new Telerik.Reporting.TextBox();
            this.textBox4 = new Telerik.Reporting.TextBox();
            this.textBox5 = new Telerik.Reporting.TextBox();
            this.INN2 = new Telerik.Reporting.TextBox();
            this.textBox7 = new Telerik.Reporting.TextBox();
            this.RegNum2 = new Telerik.Reporting.TextBox();
            this.textBox3 = new Telerik.Reporting.TextBox();
            this.nameShort = new Telerik.Reporting.TextBox();
            this.panel1 = new Telerik.Reporting.Panel();
            this.textBox6 = new Telerik.Reporting.TextBox();
            this.list4 = new Telerik.Reporting.List();
            this.textBox8 = new Telerik.Reporting.TextBox();
            this.ishCheckBox = new Telerik.Reporting.TextBox();
            this.list1 = new Telerik.Reporting.List();
            this.textBox11 = new Telerik.Reporting.TextBox();
            this.dopCheckBox = new Telerik.Reporting.TextBox();
            this.list2 = new Telerik.Reporting.List();
            this.textBox14 = new Telerik.Reporting.TextBox();
            this.naznCheckBox = new Telerik.Reporting.TextBox();
            this.textBox13 = new Telerik.Reporting.TextBox();
            this.textBox15 = new Telerik.Reporting.TextBox();
            this.Year = new Telerik.Reporting.TextBox();
            this.textBox17 = new Telerik.Reporting.TextBox();
            this.textBox16 = new Telerik.Reporting.TextBox();
            this.table12 = new Telerik.Reporting.Table();
            this.textBox86 = new Telerik.Reporting.TextBox();
            this.textBox88 = new Telerik.Reporting.TextBox();
            this.textBox90 = new Telerik.Reporting.TextBox();
            this.textBox92 = new Telerik.Reporting.TextBox();
            this.textBox94 = new Telerik.Reporting.TextBox();
            this.textBox96 = new Telerik.Reporting.TextBox();
            this.textBox98 = new Telerik.Reporting.TextBox();
            this.textBox100 = new Telerik.Reporting.TextBox();
            this.textBox102 = new Telerik.Reporting.TextBox();
            this.textBox19 = new Telerik.Reporting.TextBox();
            this.textBox21 = new Telerik.Reporting.TextBox();
            this.textBox23 = new Telerik.Reporting.TextBox();
            this.textBox25 = new Telerik.Reporting.TextBox();
            this.textBox31 = new Telerik.Reporting.TextBox();
            this.list3 = new Telerik.Reporting.List();
            this.textBox30 = new Telerik.Reporting.TextBox();
            this.textBox32 = new Telerik.Reporting.TextBox();
            this.OPSFeeNachYes = new Telerik.Reporting.TextBox();
            this.textBox36 = new Telerik.Reporting.TextBox();
            this.OPSFeeNachNo = new Telerik.Reporting.TextBox();
            this.list5 = new Telerik.Reporting.List();
            this.textBox33 = new Telerik.Reporting.TextBox();
            this.textBox35 = new Telerik.Reporting.TextBox();
            this.DopTarFeeNachYes = new Telerik.Reporting.TextBox();
            this.textBox39 = new Telerik.Reporting.TextBox();
            this.DopTarFeeNachNo = new Telerik.Reporting.TextBox();
            this.textBox34 = new Telerik.Reporting.TextBox();
            this.textBox37 = new Telerik.Reporting.TextBox();
            this.textBox46 = new Telerik.Reporting.TextBox();
            this.ConfirmDolgn = new Telerik.Reporting.TextBox();
            this.textBox55 = new Telerik.Reporting.TextBox();
            this.textBox56 = new Telerik.Reporting.TextBox();
            this.ConfirmFIO = new Telerik.Reporting.TextBox();
            this.textBox57 = new Telerik.Reporting.TextBox();
            this.DateFilling = new Telerik.Reporting.TextBox();
            this.textBox58 = new Telerik.Reporting.TextBox();
            this.textBox38 = new Telerik.Reporting.TextBox();
            this.table1 = new Telerik.Reporting.Table();
            this.textBox43 = new Telerik.Reporting.TextBox();
            this.textBox49 = new Telerik.Reporting.TextBox();
            this.textBox51 = new Telerik.Reporting.TextBox();
            this.textBox41 = new Telerik.Reporting.TextBox();
            this.textBox47 = new Telerik.Reporting.TextBox();
            this.textBox50 = new Telerik.Reporting.TextBox();
            this.textBox52 = new Telerik.Reporting.TextBox();
            this.textBox53 = new Telerik.Reporting.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // textBox85
            // 
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.60217195749282837D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox85.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox85.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox85.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox85.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox85.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox85.Value = "� �/�";
            // 
            // textBox24
            // 
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.538330078125D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox24.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox24.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox24.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox24.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox24.StyleName = "";
            this.textBox24.Value = "�������";
            // 
            // textBox22
            // 
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1134583950042725D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox22.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox22.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox22.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox22.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox22.StyleName = "";
            this.textBox22.Value = "���";
            // 
            // textBox20
            // 
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2454116344451904D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox20.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox20.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox20.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox20.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox20.StyleName = "";
            this.textBox20.Value = "��������";
            // 
            // textBox18
            // 
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7503190040588379D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox18.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox18.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox18.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox18.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox18.StyleName = "";
            this.textBox18.Value = "�����";
            // 
            // textBox27
            // 
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.645938515663147D), Telerik.Reporting.Drawing.Unit.Cm(1.5672919750213623D));
            this.textBox27.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox27.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox27.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox27.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox27.StyleName = "";
            this.textBox27.Value = "� ��.��.����";
            // 
            // textBox28
            // 
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6503289937973023D), Telerik.Reporting.Drawing.Unit.Cm(1.5672919750213623D));
            this.textBox28.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox28.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox28.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox28.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox28.StyleName = "";
            this.textBox28.Value = "�� ��.��.����";
            // 
            // textBox87
            // 
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2962675094604492D), Telerik.Reporting.Drawing.Unit.Cm(1.7524998188018799D));
            this.textBox87.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox87.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox87.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox87.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox87.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox87.Value = "������ ������";
            // 
            // textBox91
            // 
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7724049091339111D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox91.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox91.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox91.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox91.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox91.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox91.StyleName = "";
            this.textBox91.Value = "��������������� ������� (���)";
            // 
            // textBox93
            // 
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9010257720947266D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox93.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox93.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox93.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox93.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox93.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox93.StyleName = "";
            this.textBox93.Value = "������ ������� ����� (���)";
            // 
            // textBox106
            // 
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.20796799659729D), Telerik.Reporting.Drawing.Unit.Cm(1.5672919750213623D));
            this.textBox106.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox106.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox106.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox106.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox106.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox106.StyleName = "";
            this.textBox106.Value = "��������� (���)";
            // 
            // textBox107
            // 
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.367110013961792D), Telerik.Reporting.Drawing.Unit.Cm(1.5672919750213623D));
            this.textBox107.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox107.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox107.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox107.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox107.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox107.StyleName = "";
            this.textBox107.Value = "�������������� ��������";
            // 
            // textBox95
            // 
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.575078010559082D), Telerik.Reporting.Drawing.Unit.Cm(1.7524998188018799D));
            this.textBox95.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox95.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox95.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox95.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox95.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox95.StyleName = "";
            this.textBox95.Value = "���������� ���������� �����";
            // 
            // textBox108
            // 
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1283025741577148D), Telerik.Reporting.Drawing.Unit.Cm(1.5672919750213623D));
            this.textBox108.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox108.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox108.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox108.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox108.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox108.StyleName = "";
            this.textBox108.Value = "��������� (���)";
            // 
            // textBox109
            // 
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.04864239692688D), Telerik.Reporting.Drawing.Unit.Cm(1.5672919750213623D));
            this.textBox109.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox109.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox109.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox109.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox109.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox109.StyleName = "";
            this.textBox109.Value = "�������������� ��������";
            // 
            // textBox99
            // 
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.1769442558288574D), Telerik.Reporting.Drawing.Unit.Cm(1.7524998188018799D));
            this.textBox99.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox99.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox99.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox99.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox99.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox99.StyleName = "";
            this.textBox99.Value = "������� ���������� ���������� ��������� ������";
            // 
            // textBox29
            // 
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6885905265808106D), Telerik.Reporting.Drawing.Unit.Cm(3.3197925090789795D));
            this.textBox29.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox29.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox29.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7D);
            this.textBox29.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox29.StyleName = "";
            this.textBox29.Value = "�������� �� ���������� ��������������� ���� / �������� � ��������, ������������� " +
    "� ��������� ���� �����������";
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(1.9024194478988648D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox83,
            this.RegNum,
            this.textBox12,
            this.textBox9,
            this.INN,
            this.textBox26,
            this.textBox1,
            this.KPP,
            this.textBox2});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            // 
            // textBox83
            // 
            this.textBox83.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox83.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.506667137145996D), Telerik.Reporting.Drawing.Unit.Cm(0.00010002215276472271D));
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox83.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox83.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox83.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox83.Value = "= \"���. \" + Substr(\"0000\" + PageNumber, Len(\"0000\" + PageNumber) - 5, 5)";
            // 
            // RegNum
            // 
            this.RegNum.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.RegNum.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.50029993057251D), Telerik.Reporting.Drawing.Unit.Cm(0.0045247157104313374D));
            this.RegNum.Name = "RegNum";
            this.RegNum.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.RegNum.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.RegNum.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.RegNum.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.RegNum.Value = "";
            // 
            // textBox12
            // 
            this.textBox12.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.9921220680698752E-05D), Telerik.Reporting.Drawing.Unit.Cm(0.0045247157104313374D));
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox12.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox12.Value = "��������������� ����� � ���";
            // 
            // textBox9
            // 
            this.textBox9.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(21.699901580810547D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5D), Telerik.Reporting.Drawing.Unit.Cm(1.4000002145767212D));
            this.textBox9.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(6D);
            this.textBox9.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox9.Value = "���������� � 1\r\n����������\r\n�������������� ��������� ���\r\n�� 11 ������ 2017 �. � " +
    "3�";
            // 
            // INN
            // 
            this.INN.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.50029993057251D), Telerik.Reporting.Drawing.Unit.Cm(0.70000004768371582D));
            this.INN.Name = "INN";
            this.INN.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.INN.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.INN.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.INN.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.INN.StyleName = "";
            this.INN.Value = "";
            // 
            // textBox26
            // 
            this.textBox26.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.0000998973846436D), Telerik.Reporting.Drawing.Unit.Cm(0.70000004768371582D));
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5000001192092896D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox26.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox26.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox26.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox26.StyleName = "";
            this.textBox26.Value = "���";
            // 
            // textBox1
            // 
            this.textBox1.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.998541831970215D), Telerik.Reporting.Drawing.Unit.Cm(0.70000004768371582D));
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5000001192092896D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox1.StyleName = "";
            this.textBox1.Value = "���";
            // 
            // KPP
            // 
            this.KPP.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.KPP.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.506667137145996D), Telerik.Reporting.Drawing.Unit.Cm(0.70000004768371582D));
            this.KPP.Name = "KPP";
            this.KPP.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.KPP.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.KPP.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.KPP.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.KPP.StyleName = "";
            this.KPP.Value = "";
            // 
            // textBox2
            // 
            this.textBox2.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(1.4000000953674316D));
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox2.StyleName = "";
            this.textBox2.Value = "����� ���-����";
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(15.397581100463867D);
            this.detail.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox10,
            this.KPP2,
            this.textBox4,
            this.textBox5,
            this.INN2,
            this.textBox7,
            this.RegNum2,
            this.textBox3,
            this.nameShort,
            this.panel1,
            this.textBox13,
            this.textBox15,
            this.Year,
            this.textBox17,
            this.textBox16,
            this.table12,
            this.list3,
            this.list5,
            this.textBox34,
            this.textBox37,
            this.textBox46,
            this.ConfirmDolgn,
            this.textBox55,
            this.textBox56,
            this.ConfirmFIO,
            this.textBox57,
            this.DateFilling,
            this.textBox58,
            this.textBox38,
            this.table1});
            this.detail.Name = "detail";
            // 
            // textBox10
            // 
            this.textBox10.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(9.9719363788608462E-05D), Telerik.Reporting.Drawing.Unit.Cm(0.19758079946041107D));
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(17.006567001342773D), Telerik.Reporting.Drawing.Unit.Cm(0.40000000596046448D));
            this.textBox10.Style.Font.Bold = true;
            this.textBox10.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.textBox10.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox10.Value = "�������� � ��������� ����� �������������� ���";
            // 
            // KPP2
            // 
            this.KPP2.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.KPP2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(12.490716934204102D), Telerik.Reporting.Drawing.Unit.Cm(2.0975806713104248D));
            this.KPP2.Name = "KPP2";
            this.KPP2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.KPP2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP2.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP2.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP2.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.KPP2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.KPP2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.KPP2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.KPP2.StyleName = "";
            this.KPP2.Value = "";
            // 
            // textBox4
            // 
            this.textBox4.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(10.98259162902832D), Telerik.Reporting.Drawing.Unit.Cm(2.0975806713104248D));
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5000001192092896D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox4.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox4.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox4.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox4.StyleName = "";
            this.textBox4.Value = "���";
            // 
            // textBox5
            // 
            this.textBox5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(2.9921751022338867D), Telerik.Reporting.Drawing.Unit.Cm(2.0975806713104248D));
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.5000001192092896D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox5.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox5.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox5.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox5.StyleName = "";
            this.textBox5.Value = "���";
            // 
            // INN2
            // 
            this.INN2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.50029993057251D), Telerik.Reporting.Drawing.Unit.Cm(2.0975806713104248D));
            this.INN2.Name = "INN2";
            this.INN2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.INN2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN2.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN2.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN2.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.INN2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.INN2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.INN2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.INN2.StyleName = "";
            this.INN2.Value = "";
            // 
            // textBox7
            // 
            this.textBox7.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox7.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0023835753090679646D), Telerik.Reporting.Drawing.Unit.Cm(1.4096640348434448D));
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox7.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox7.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox7.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox7.Value = "��������������� ����� � ���";
            // 
            // RegNum2
            // 
            this.RegNum2.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.RegNum2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.5025839805603027D), Telerik.Reporting.Drawing.Unit.Cm(1.4096640348434448D));
            this.RegNum2.Name = "RegNum2";
            this.RegNum2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.RegNum2.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum2.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum2.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum2.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum2.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.RegNum2.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.RegNum2.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.RegNum2.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.RegNum2.Value = "";
            // 
            // textBox3
            // 
            this.textBox3.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0023839790374040604D), Telerik.Reporting.Drawing.Unit.Cm(2.8096640110015869D));
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox3.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox3.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox3.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox3.Value = "������������ (�������)";
            // 
            // nameShort
            // 
            this.nameShort.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.5025844573974609D), Telerik.Reporting.Drawing.Unit.Cm(2.8040297031402588D));
            this.nameShort.Name = "nameShort";
            this.nameShort.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(14.797414779663086D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.nameShort.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.nameShort.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.nameShort.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.nameShort.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.nameShort.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.nameShort.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.nameShort.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.nameShort.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.nameShort.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.nameShort.StyleName = "";
            this.nameShort.Value = "";
            // 
            // panel1
            // 
            this.panel1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox6,
            this.list4,
            this.list1,
            this.list2});
            this.panel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(19.600000381469727D), Telerik.Reporting.Drawing.Unit.Cm(0.61218363046646118D));
            this.panel1.Name = "panel1";
            this.panel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(7.0998992919921875D), Telerik.Reporting.Drawing.Unit.Cm(2.6974806785583496D));
            this.panel1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.panel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            // 
            // textBox6
            // 
            this.textBox6.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox6.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9999992847442627D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox6.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox6.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox6.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox6.StyleName = "";
            this.textBox6.Value = "��� ��������:";
            // 
            // list4
            // 
            this.list4.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.0447921752929688D)));
            this.list4.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.65604156255722046D)));
            this.list4.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.5D)));
            this.list4.Body.SetCellContent(0, 0, this.textBox8);
            this.list4.Body.SetCellContent(0, 1, this.ishCheckBox);
            tableGroup1.Name = "group3";
            tableGroup2.Name = "ColumnGroup";
            this.list4.ColumnGroups.Add(tableGroup1);
            this.list4.ColumnGroups.Add(tableGroup2);
            this.list4.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox8,
            this.ishCheckBox});
            this.list4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.00010012308484874666D), Telerik.Reporting.Drawing.Unit.Cm(0.79748034477233887D));
            this.list4.Name = "list4";
            tableGroup4.Name = "group4";
            tableGroup3.ChildGroups.Add(tableGroup4);
            tableGroup3.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup3.Name = "DetailGroup";
            this.list4.RowGroups.Add(tableGroup3);
            this.list4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.700833797454834D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            // 
            // textBox8
            // 
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0447919368743896D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox8.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox8.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox8.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox8.StyleName = "";
            this.textBox8.Value = "�������� -";
            // 
            // ishCheckBox
            // 
            this.ishCheckBox.Name = "ishCheckBox";
            this.ishCheckBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.65604156255722046D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.ishCheckBox.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ishCheckBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ishCheckBox.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ishCheckBox.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ishCheckBox.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ishCheckBox.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.ishCheckBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.ishCheckBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.ishCheckBox.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ishCheckBox.StyleName = "";
            this.ishCheckBox.Value = "";
            // 
            // list1
            // 
            this.list1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.6268754005432129D)));
            this.list1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.65604162216186523D)));
            this.list1.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.5D)));
            this.list1.Body.SetCellContent(0, 0, this.textBox11);
            this.list1.Body.SetCellContent(0, 1, this.dopCheckBox);
            tableGroup5.Name = "group3";
            tableGroup6.Name = "ColumnGroup";
            this.list1.ColumnGroups.Add(tableGroup5);
            this.list1.ColumnGroups.Add(tableGroup6);
            this.list1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox11,
            this.dopCheckBox});
            this.list1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(3.4000008106231689D), Telerik.Reporting.Drawing.Unit.Cm(0.79748034477233887D));
            this.list1.Name = "list1";
            tableGroup8.Name = "group4";
            tableGroup7.ChildGroups.Add(tableGroup8);
            tableGroup7.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup7.Name = "DetailGroup";
            this.list1.RowGroups.Add(tableGroup7);
            this.list1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2829170227050781D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            // 
            // textBox11
            // 
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.626875638961792D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox11.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox11.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox11.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox11.StyleName = "";
            this.textBox11.Value = "����������� -";
            // 
            // dopCheckBox
            // 
            this.dopCheckBox.Name = "dopCheckBox";
            this.dopCheckBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.65604156255722046D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.dopCheckBox.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.dopCheckBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.dopCheckBox.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.dopCheckBox.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Solid;
            this.dopCheckBox.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
            this.dopCheckBox.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.dopCheckBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.dopCheckBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.dopCheckBox.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.dopCheckBox.StyleName = "";
            this.dopCheckBox.Value = "";
            // 
            // list2
            // 
            this.list2.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.3147919178009033D)));
            this.list2.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.65604144334793091D)));
            this.list2.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.5D)));
            this.list2.Body.SetCellContent(0, 0, this.textBox14);
            this.list2.Body.SetCellContent(0, 1, this.naznCheckBox);
            tableGroup9.Name = "group3";
            tableGroup10.Name = "ColumnGroup";
            this.list2.ColumnGroups.Add(tableGroup9);
            this.list2.ColumnGroups.Add(tableGroup10);
            this.list2.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox14,
            this.naznCheckBox});
            this.list2.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.05510968342423439D), Telerik.Reporting.Drawing.Unit.Cm(1.4878160953521729D));
            this.list2.Name = "list2";
            tableGroup12.Name = "group4";
            tableGroup11.ChildGroups.Add(tableGroup12);
            tableGroup11.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup11.Name = "DetailGroup";
            this.list2.RowGroups.Add(tableGroup11);
            this.list2.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.9708335399627686D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            // 
            // textBox14
            // 
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.3147923946380615D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox14.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.textBox14.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox14.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox14.StyleName = "";
            this.textBox14.Value = "���������� ������ -";
            // 
            // naznCheckBox
            // 
            this.naznCheckBox.Name = "naznCheckBox";
            this.naznCheckBox.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.65604156255722046D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.naznCheckBox.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.naznCheckBox.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.naznCheckBox.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Solid;
            this.naznCheckBox.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Solid;
            this.naznCheckBox.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Solid;
            this.naznCheckBox.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.naznCheckBox.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.naznCheckBox.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.naznCheckBox.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.naznCheckBox.StyleName = "";
            this.naznCheckBox.Value = "";
            // 
            // textBox13
            // 
            this.textBox13.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox13.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0.79758048057556152D));
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox13.Style.Font.Bold = true;
            this.textBox13.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox13.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox13.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox13.Value = "1. �������� � ������������";
            // 
            // textBox15
            // 
            this.textBox15.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox15.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0023843827657401562D), Telerik.Reporting.Drawing.Unit.Cm(3.5975806713104248D));
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox15.Style.Font.Bold = true;
            this.textBox15.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox15.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox15.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox15.Value = "2. �������� ������";
            // 
            // Year
            // 
            this.Year.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.Year.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(4.5025849342346191D), Telerik.Reporting.Drawing.Unit.Cm(4.2061223983764648D));
            this.Year.Name = "Year";
            this.Year.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0974149703979492D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.Year.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.Year.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.Year.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.Year.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.Year.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.Dotted;
            this.Year.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8.5D);
            this.Year.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.Year.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.Year.Value = "";
            // 
            // textBox17
            // 
            this.textBox17.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox17.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0023843827657401562D), Telerik.Reporting.Drawing.Unit.Cm(4.2061223983764648D));
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.5D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox17.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox17.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox17.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox17.Value = "����������� ���";
            // 
            // textBox16
            // 
            this.textBox16.Anchoring = Telerik.Reporting.AnchoringStyles.Top;
            this.textBox16.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(4.9975810050964355D));
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(8.3000001907348633D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox16.Style.Font.Bold = true;
            this.textBox16.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox16.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox16.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox16.Value = "3. �������� � �������� ������ �������������� ���";
            // 
            // table12
            // 
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.60217195749282837D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.538330078125D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.1134583950042725D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.2454116344451904D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.7503190040588379D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.645938515663147D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.6503289937973023D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.7724049091339111D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.9010257720947266D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.20796799659729D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.367110013961792D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.1283025741577148D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.04864239692688D)));
            this.table12.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.6885905265808106D)));
            this.table12.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.39999997615814209D)));
            this.table12.Body.SetCellContent(0, 0, this.textBox86);
            this.table12.Body.SetCellContent(0, 5, this.textBox88);
            this.table12.Body.SetCellContent(0, 6, this.textBox90);
            this.table12.Body.SetCellContent(0, 7, this.textBox92);
            this.table12.Body.SetCellContent(0, 8, this.textBox94);
            this.table12.Body.SetCellContent(0, 9, this.textBox96);
            this.table12.Body.SetCellContent(0, 10, this.textBox98);
            this.table12.Body.SetCellContent(0, 11, this.textBox100);
            this.table12.Body.SetCellContent(0, 12, this.textBox102);
            this.table12.Body.SetCellContent(0, 4, this.textBox19);
            this.table12.Body.SetCellContent(0, 3, this.textBox21);
            this.table12.Body.SetCellContent(0, 2, this.textBox23);
            this.table12.Body.SetCellContent(0, 1, this.textBox25);
            this.table12.Body.SetCellContent(0, 13, this.textBox31);
            tableGroup13.Name = "group49";
            tableGroup13.ReportItem = this.textBox85;
            tableGroup14.Name = "group5";
            tableGroup14.ReportItem = this.textBox24;
            tableGroup15.Name = "group2";
            tableGroup15.ReportItem = this.textBox22;
            tableGroup16.Name = "group1";
            tableGroup16.ReportItem = this.textBox20;
            tableGroup17.Name = "group";
            tableGroup17.ReportItem = this.textBox18;
            tableGroup19.Name = "group6";
            tableGroup19.ReportItem = this.textBox27;
            tableGroup20.Name = "group7";
            tableGroup20.ReportItem = this.textBox28;
            tableGroup18.ChildGroups.Add(tableGroup19);
            tableGroup18.ChildGroups.Add(tableGroup20);
            tableGroup18.Name = "group50";
            tableGroup18.ReportItem = this.textBox87;
            tableGroup21.Name = "group52";
            tableGroup21.ReportItem = this.textBox91;
            tableGroup22.Name = "group53";
            tableGroup22.ReportItem = this.textBox93;
            tableGroup25.Name = "group47";
            tableGroup24.ChildGroups.Add(tableGroup25);
            tableGroup24.Name = "group54";
            tableGroup24.ReportItem = this.textBox106;
            tableGroup27.Name = "group44";
            tableGroup26.ChildGroups.Add(tableGroup27);
            tableGroup26.Name = "group55";
            tableGroup26.ReportItem = this.textBox107;
            tableGroup23.ChildGroups.Add(tableGroup24);
            tableGroup23.ChildGroups.Add(tableGroup26);
            tableGroup23.Name = "group58";
            tableGroup23.ReportItem = this.textBox95;
            tableGroup30.Name = "group48";
            tableGroup29.ChildGroups.Add(tableGroup30);
            tableGroup29.Name = "group56";
            tableGroup29.ReportItem = this.textBox108;
            tableGroup32.Name = "group46";
            tableGroup31.ChildGroups.Add(tableGroup32);
            tableGroup31.Name = "group57";
            tableGroup31.ReportItem = this.textBox109;
            tableGroup28.ChildGroups.Add(tableGroup29);
            tableGroup28.ChildGroups.Add(tableGroup31);
            tableGroup28.Name = "group59";
            tableGroup28.ReportItem = this.textBox99;
            tableGroup34.Name = "group10";
            tableGroup33.ChildGroups.Add(tableGroup34);
            tableGroup33.Name = "group8";
            tableGroup33.ReportItem = this.textBox29;
            this.table12.ColumnGroups.Add(tableGroup13);
            this.table12.ColumnGroups.Add(tableGroup14);
            this.table12.ColumnGroups.Add(tableGroup15);
            this.table12.ColumnGroups.Add(tableGroup16);
            this.table12.ColumnGroups.Add(tableGroup17);
            this.table12.ColumnGroups.Add(tableGroup18);
            this.table12.ColumnGroups.Add(tableGroup21);
            this.table12.ColumnGroups.Add(tableGroup22);
            this.table12.ColumnGroups.Add(tableGroup23);
            this.table12.ColumnGroups.Add(tableGroup28);
            this.table12.ColumnGroups.Add(tableGroup33);
            this.table12.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox86,
            this.textBox25,
            this.textBox23,
            this.textBox21,
            this.textBox19,
            this.textBox88,
            this.textBox90,
            this.textBox92,
            this.textBox94,
            this.textBox96,
            this.textBox98,
            this.textBox100,
            this.textBox102,
            this.textBox31,
            this.textBox85,
            this.textBox24,
            this.textBox22,
            this.textBox20,
            this.textBox18,
            this.textBox87,
            this.textBox27,
            this.textBox28,
            this.textBox91,
            this.textBox93,
            this.textBox95,
            this.textBox106,
            this.textBox107,
            this.textBox99,
            this.textBox108,
            this.textBox109,
            this.textBox29});
            this.table12.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0023843827657401562D), Telerik.Reporting.Drawing.Unit.Cm(5.4977812767028809D));
            this.table12.Name = "table12";
            tableGroup35.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup35.Name = "detailTableGroup8";
            this.table12.RowGroups.Add(tableGroup35);
            this.table12.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(26.660001754760742D), Telerik.Reporting.Drawing.Unit.Cm(3.719792366027832D));
            this.table12.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.table12.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(10D);
            this.table12.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.table12.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            // 
            // textBox86
            // 
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.6021723747253418D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox86.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox86.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox86.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox86.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox86.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox86.Value = "1";
            // 
            // textBox88
            // 
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6459391117095947D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox88.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox88.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox88.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox88.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox88.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox88.Value = "6";
            // 
            // textBox90
            // 
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6503307819366455D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox90.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox90.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox90.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox90.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox90.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox90.Value = "7";
            // 
            // textBox92
            // 
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7724031209945679D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox92.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox92.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox92.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox92.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox92.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox92.StyleName = "";
            this.textBox92.Value = "8";
            // 
            // textBox94
            // 
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.9010264873504639D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox94.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox94.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox94.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox94.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox94.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox94.StyleName = "";
            this.textBox94.Value = "9";
            // 
            // textBox96
            // 
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2079665660858154D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox96.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox96.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox96.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox96.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox96.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox96.StyleName = "";
            this.textBox96.Value = "10";
            // 
            // textBox98
            // 
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.3671109676361084D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox98.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox98.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox98.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox98.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox98.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox98.StyleName = "";
            this.textBox98.Value = "11";
            // 
            // textBox100
            // 
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1283032894134521D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox100.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox100.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox100.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox100.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox100.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox100.StyleName = "";
            this.textBox100.Value = "12";
            // 
            // textBox102
            // 
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.0486416816711426D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox102.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox102.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox102.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox102.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox102.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox102.StyleName = "";
            this.textBox102.Value = "13";
            // 
            // textBox19
            // 
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.7503178119659424D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox19.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox19.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox19.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox19.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox19.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox19.StyleName = "";
            this.textBox19.Value = "5";
            // 
            // textBox21
            // 
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.2454111576080322D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox21.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox21.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox21.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox21.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox21.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox21.StyleName = "";
            this.textBox21.TextWrap = true;
            this.textBox21.Value = "4";
            // 
            // textBox23
            // 
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.1134588718414307D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox23.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox23.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox23.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox23.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox23.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox23.StyleName = "";
            this.textBox23.TextWrap = true;
            this.textBox23.Value = "3";
            // 
            // textBox25
            // 
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.538325309753418D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox25.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox25.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox25.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox25.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox25.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox25.StyleName = "";
            this.textBox25.TextWrap = true;
            this.textBox25.Value = "2";
            // 
            // textBox31
            // 
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.6885919570922852D), Telerik.Reporting.Drawing.Unit.Cm(0.40000003576278687D));
            this.textBox31.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox31.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox31.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(7.5D);
            this.textBox31.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox31.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox31.StyleName = "";
            this.textBox31.Value = "14";
            // 
            // list3
            // 
            this.list3.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18.970621109008789D)));
            this.list3.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.3385412693023682D)));
            this.list3.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.7000001072883606D)));
            this.list3.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.2327078580856323D)));
            this.list3.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.7000001072883606D)));
            this.list3.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D)));
            this.list3.Body.SetCellContent(0, 0, this.textBox30);
            this.list3.Body.SetCellContent(0, 1, this.textBox32);
            this.list3.Body.SetCellContent(0, 2, this.OPSFeeNachYes);
            this.list3.Body.SetCellContent(0, 3, this.textBox36);
            this.list3.Body.SetCellContent(0, 4, this.OPSFeeNachNo);
            tableGroup36.Name = "ColumnGroup";
            tableGroup37.Name = "group12";
            tableGroup38.Name = "group13";
            tableGroup39.Name = "group14";
            tableGroup40.Name = "group15";
            this.list3.ColumnGroups.Add(tableGroup36);
            this.list3.ColumnGroups.Add(tableGroup37);
            this.list3.ColumnGroups.Add(tableGroup38);
            this.list3.ColumnGroups.Add(tableGroup39);
            this.list3.ColumnGroups.Add(tableGroup40);
            this.list3.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox30,
            this.textBox32,
            this.OPSFeeNachYes,
            this.textBox36,
            this.OPSFeeNachNo});
            this.list3.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.89758014678955D));
            this.list3.Name = "list3";
            tableGroup42.Name = "group11";
            tableGroup41.ChildGroups.Add(tableGroup42);
            tableGroup41.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup41.Name = "DetailGroup";
            this.list3.RowGroups.Add(tableGroup41);
            this.list3.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.941871643066406D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            // 
            // textBox30
            // 
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.970621109008789D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.textBox30.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox30.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox30.StyleName = "";
            this.textBox30.Value = "��������� ������ �� ������������ ���������� ����������� �� ������, ��������� � ��" +
    "��� \"������ ������\", ��������� (��������):";
            // 
            // textBox32
            // 
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3385415077209473D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.textBox32.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox32.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox32.StyleName = "";
            this.textBox32.Value = "�� -";
            // 
            // OPSFeeNachYes
            // 
            this.OPSFeeNachYes.Name = "OPSFeeNachYes";
            this.OPSFeeNachYes.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.699999988079071D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.OPSFeeNachYes.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OPSFeeNachYes.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.OPSFeeNachYes.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.OPSFeeNachYes.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.OPSFeeNachYes.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.OPSFeeNachYes.StyleName = "";
            this.OPSFeeNachYes.Value = "";
            // 
            // textBox36
            // 
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2327075004577637D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.textBox36.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox36.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox36.StyleName = "";
            this.textBox36.Value = "��� -";
            // 
            // OPSFeeNachNo
            // 
            this.OPSFeeNachNo.Name = "OPSFeeNachNo";
            this.OPSFeeNachNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.699999988079071D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.OPSFeeNachNo.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.OPSFeeNachNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.OPSFeeNachNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.OPSFeeNachNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.OPSFeeNachNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.OPSFeeNachNo.StyleName = "";
            // 
            // list5
            // 
            this.list5.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(18.970621109008789D)));
            this.list5.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.3385412693023682D)));
            this.list5.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.7000001072883606D)));
            this.list5.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.2327078580856323D)));
            this.list5.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.7000001072883606D)));
            this.list5.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D)));
            this.list5.Body.SetCellContent(0, 0, this.textBox33);
            this.list5.Body.SetCellContent(0, 1, this.textBox35);
            this.list5.Body.SetCellContent(0, 2, this.DopTarFeeNachYes);
            this.list5.Body.SetCellContent(0, 3, this.textBox39);
            this.list5.Body.SetCellContent(0, 4, this.DopTarFeeNachNo);
            tableGroup43.Name = "ColumnGroup";
            tableGroup44.Name = "group12";
            tableGroup45.Name = "group13";
            tableGroup46.Name = "group14";
            tableGroup47.Name = "group15";
            this.list5.ColumnGroups.Add(tableGroup43);
            this.list5.ColumnGroups.Add(tableGroup44);
            this.list5.ColumnGroups.Add(tableGroup45);
            this.list5.ColumnGroups.Add(tableGroup46);
            this.list5.ColumnGroups.Add(tableGroup47);
            this.list5.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox33,
            this.textBox35,
            this.DopTarFeeNachYes,
            this.textBox39,
            this.DopTarFeeNachNo});
            this.list5.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(10.597580909729004D));
            this.list5.Name = "list5";
            tableGroup49.Name = "group11";
            tableGroup48.ChildGroups.Add(tableGroup49);
            tableGroup48.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup48.Name = "DetailGroup";
            this.list5.RowGroups.Add(tableGroup48);
            this.list5.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.941871643066406D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            // 
            // textBox33
            // 
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.970621109008789D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.textBox33.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox33.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox33.StyleName = "";
            this.textBox33.Value = "��������� ������ �� ��������������� ������ �� ������, ��������� � ����� \"������ �" +
    "�����\", ���������:";
            // 
            // textBox35
            // 
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.3385415077209473D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.textBox35.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox35.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox35.StyleName = "";
            this.textBox35.Value = "�� -";
            // 
            // DopTarFeeNachYes
            // 
            this.DopTarFeeNachYes.Name = "DopTarFeeNachYes";
            this.DopTarFeeNachYes.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.699999988079071D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.DopTarFeeNachYes.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DopTarFeeNachYes.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.DopTarFeeNachYes.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.DopTarFeeNachYes.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.DopTarFeeNachYes.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DopTarFeeNachYes.StyleName = "";
            // 
            // textBox39
            // 
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.2327075004577637D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.textBox39.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox39.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox39.StyleName = "";
            this.textBox39.Value = "��� -";
            // 
            // DopTarFeeNachNo
            // 
            this.DopTarFeeNachNo.Name = "DopTarFeeNachNo";
            this.DopTarFeeNachNo.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.699999988079071D), Telerik.Reporting.Drawing.Unit.Cm(0.57937520742416382D));
            this.DopTarFeeNachNo.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DopTarFeeNachNo.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.DopTarFeeNachNo.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.DopTarFeeNachNo.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.DopTarFeeNachNo.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DopTarFeeNachNo.StyleName = "";
            // 
            // textBox34
            // 
            this.textBox34.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(9.3973808288574219D));
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(16.427143096923828D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox34.Style.Font.Bold = true;
            this.textBox34.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox34.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox34.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox34.Value = "4.  �������� � ����������� (����������) ��������� ������� �� ������������ �������" +
    "��� �����������";
            // 
            // textBox37
            // 
            this.textBox37.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(11.397581100463867D));
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(22.941871643066406D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox37.Style.Font.Bold = true;
            this.textBox37.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox37.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Left;
            this.textBox37.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox37.Value = "5. �������� �� ���������� ���������� ������� � ������������ � ����������� �������" +
    "��� ���������� ������������������ ����������� �����������:";
            // 
            // textBox46
            // 
            this.textBox46.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.0023843827657401562D), Telerik.Reporting.Drawing.Unit.Cm(13.197580337524414D));
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(5.2507734298706055D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox46.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox46.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox46.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox46.StyleName = "";
            this.textBox46.Value = "������������ ���������";
            // 
            // ConfirmDolgn
            // 
            this.ConfirmDolgn.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(5.2533583641052246D), Telerik.Reporting.Drawing.Unit.Cm(13.197580337524414D));
            this.ConfirmDolgn.Name = "ConfirmDolgn";
            this.ConfirmDolgn.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5934839248657227D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.ConfirmDolgn.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ConfirmDolgn.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmDolgn.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmDolgn.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmDolgn.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmDolgn.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(2D);
            this.ConfirmDolgn.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.ConfirmDolgn.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.ConfirmDolgn.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ConfirmDolgn.StyleName = "";
            this.ConfirmDolgn.Value = "";
            // 
            // textBox55
            // 
            this.textBox55.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.506866455078125D), Telerik.Reporting.Drawing.Unit.Cm(13.197580337524414D));
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5934839248657227D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox55.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox55.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox55.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox55.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox55.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.textBox55.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(2D);
            this.textBox55.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox55.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox55.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox55.StyleName = "";
            this.textBox55.Value = "";
            // 
            // textBox56
            // 
            this.textBox56.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.848808288574219D), Telerik.Reporting.Drawing.Unit.Cm(13.197580337524414D));
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6578571796417236D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox56.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox56.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox56.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox56.StyleName = "";
            this.textBox56.Value = "�������";
            // 
            // ConfirmFIO
            // 
            this.ConfirmFIO.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(15.506866455078125D), Telerik.Reporting.Drawing.Unit.Cm(13.797581672668457D));
            this.ConfirmFIO.Name = "ConfirmFIO";
            this.ConfirmFIO.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.5934839248657227D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.ConfirmFIO.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.ConfirmFIO.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmFIO.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmFIO.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmFIO.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.ConfirmFIO.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(2D);
            this.ConfirmFIO.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.ConfirmFIO.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.ConfirmFIO.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.ConfirmFIO.StyleName = "";
            this.ConfirmFIO.Value = "";
            // 
            // textBox57
            // 
            this.textBox57.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(11.829157829284668D), Telerik.Reporting.Drawing.Unit.Cm(13.797581672668457D));
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.6578571796417236D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.textBox57.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox57.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Right;
            this.textBox57.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox57.StyleName = "";
            this.textBox57.Value = "����������� �������";
            // 
            // DateFilling
            // 
            this.DateFilling.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(14.297582626342773D));
            this.DateFilling.Name = "DateFilling";
            this.DateFilling.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0466423034667969D), Telerik.Reporting.Drawing.Unit.Cm(0.50241923332214355D));
            this.DateFilling.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.DateFilling.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.None;
            this.DateFilling.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.DateFilling.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.None;
            this.DateFilling.Style.BorderStyle.Top = Telerik.Reporting.Drawing.BorderType.None;
            this.DateFilling.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.DateFilling.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.DateFilling.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.DateFilling.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.DateFilling.StyleName = "";
            this.DateFilling.Value = "";
            // 
            // textBox58
            // 
            this.textBox58.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.002384786494076252D), Telerik.Reporting.Drawing.Unit.Cm(14.800207138061523D));
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0442571640014648D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox58.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox58.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox58.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox58.Value = "���� (��.��.����)";
            // 
            // textBox38
            // 
            this.textBox38.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(8.8025846481323242D), Telerik.Reporting.Drawing.Unit.Cm(14.800204277038574D));
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.0442571640014648D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox38.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.textBox38.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.textBox38.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            this.textBox38.Value = "�.�. (��� �������)";
            // 
            // table1
            // 
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(4.7976346015930176D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.2376987934112549D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.5808405876159668D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(3.2893803119659424D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(2.8925032615661621D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.6964600682258606D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(1.0139592885971069D)));
            this.table1.Body.Columns.Add(new Telerik.Reporting.TableBodyColumn(Telerik.Reporting.Drawing.Unit.Cm(0.77583587169647217D)));
            this.table1.Body.Rows.Add(new Telerik.Reporting.TableBodyRow(Telerik.Reporting.Drawing.Unit.Cm(0.5D)));
            this.table1.Body.SetCellContent(0, 0, this.textBox43);
            this.table1.Body.SetCellContent(0, 1, this.textBox49);
            this.table1.Body.SetCellContent(0, 2, this.textBox51);
            this.table1.Body.SetCellContent(0, 3, this.textBox41);
            this.table1.Body.SetCellContent(0, 4, this.textBox47);
            this.table1.Body.SetCellContent(0, 5, this.textBox50);
            this.table1.Body.SetCellContent(0, 6, this.textBox52);
            this.table1.Body.SetCellContent(0, 7, this.textBox53);
            tableGroup50.Name = "tableGroup";
            tableGroup51.Name = "tableGroup1";
            tableGroup52.Name = "tableGroup2";
            tableGroup53.Name = "group23";
            tableGroup54.Name = "group24";
            tableGroup55.Name = "group25";
            tableGroup56.Name = "group26";
            tableGroup57.Name = "group27";
            this.table1.ColumnGroups.Add(tableGroup50);
            this.table1.ColumnGroups.Add(tableGroup51);
            this.table1.ColumnGroups.Add(tableGroup52);
            this.table1.ColumnGroups.Add(tableGroup53);
            this.table1.ColumnGroups.Add(tableGroup54);
            this.table1.ColumnGroups.Add(tableGroup55);
            this.table1.ColumnGroups.Add(tableGroup56);
            this.table1.ColumnGroups.Add(tableGroup57);
            this.table1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.textBox43,
            this.textBox49,
            this.textBox51,
            this.textBox41,
            this.textBox47,
            this.textBox50,
            this.textBox52,
            this.textBox53});
            this.table1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0.030925113707780838D), Telerik.Reporting.Drawing.Unit.Cm(12.080096244812012D));
            this.table1.Name = "table1";
            tableGroup58.Groupings.Add(new Telerik.Reporting.Grouping(null));
            tableGroup58.Name = "detailTableGroup";
            this.table1.RowGroups.Add(tableGroup58);
            this.table1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(17.284313201904297D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.table1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(8D);
            this.table1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.table1.Style.VerticalAlign = Telerik.Reporting.Drawing.VerticalAlign.Middle;
            // 
            // textBox43
            // 
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(4.7976350784301758D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox43.Value = "���������� ������ �� ������ �";
            // 
            // textBox49
            // 
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2376987934112549D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox49.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox49.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            // 
            // textBox51
            // 
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.5808405876159668D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox51.Value = "��";
            // 
            // textBox41
            // 
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(3.2893803119659424D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox41.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox41.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox41.StyleName = "";
            // 
            // textBox47
            // 
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(2.8925034999847412D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox47.StyleName = "";
            this.textBox47.Value = ", ��������:  �� -";
            // 
            // textBox50
            // 
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.69646018743515015D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox50.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox50.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox50.StyleName = "";
            // 
            // textBox52
            // 
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(1.0139592885971069D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox52.StyleName = "";
            this.textBox52.Value = "��� -";
            // 
            // textBox53
            // 
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(0.77583557367324829D), Telerik.Reporting.Drawing.Unit.Cm(0.5D));
            this.textBox53.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.textBox53.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Pixel(1D);
            this.textBox53.StyleName = "";
            // 
            // SZV_STAJ_Rep
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail});
            this.Name = "SZV_STAJ_Rep";
            this.PageSettings.Landscape = true;
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Mm(15D), Telerik.Reporting.Drawing.Unit.Mm(15D), Telerik.Reporting.Drawing.Unit.Mm(15D), Telerik.Reporting.Drawing.Unit.Mm(15D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(26.702384948730469D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }
        #endregion

        private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
        private Telerik.Reporting.DetailSection detail;
        private Telerik.Reporting.TextBox textBox83;
        private Telerik.Reporting.TextBox RegNum;
        private Telerik.Reporting.TextBox textBox12;
        private Telerik.Reporting.TextBox textBox9;
        private Telerik.Reporting.TextBox INN;
        private Telerik.Reporting.TextBox textBox26;
        private Telerik.Reporting.TextBox textBox1;
        private Telerik.Reporting.TextBox KPP;
        private Telerik.Reporting.TextBox textBox2;
        private Telerik.Reporting.TextBox textBox10;
        private Telerik.Reporting.TextBox KPP2;
        private Telerik.Reporting.TextBox textBox4;
        private Telerik.Reporting.TextBox textBox5;
        private Telerik.Reporting.TextBox INN2;
        private Telerik.Reporting.TextBox textBox7;
        private Telerik.Reporting.TextBox RegNum2;
        private Telerik.Reporting.TextBox textBox3;
        private Telerik.Reporting.TextBox nameShort;
        private Telerik.Reporting.Panel panel1;
        private Telerik.Reporting.TextBox textBox6;
        private Telerik.Reporting.List list4;
        private Telerik.Reporting.TextBox textBox8;
        private Telerik.Reporting.TextBox ishCheckBox;
        private Telerik.Reporting.List list1;
        private Telerik.Reporting.TextBox textBox11;
        private Telerik.Reporting.TextBox dopCheckBox;
        private Telerik.Reporting.List list2;
        private Telerik.Reporting.TextBox textBox14;
        private Telerik.Reporting.TextBox naznCheckBox;
        private Telerik.Reporting.TextBox textBox13;
        private Telerik.Reporting.TextBox textBox15;
        private Telerik.Reporting.TextBox Year;
        private Telerik.Reporting.TextBox textBox17;
        private Telerik.Reporting.TextBox textBox16;
        private Telerik.Reporting.Table table12;
        private Telerik.Reporting.TextBox textBox86;
        private Telerik.Reporting.TextBox textBox88;
        private Telerik.Reporting.TextBox textBox90;
        private Telerik.Reporting.TextBox textBox92;
        private Telerik.Reporting.TextBox textBox94;
        private Telerik.Reporting.TextBox textBox96;
        private Telerik.Reporting.TextBox textBox98;
        private Telerik.Reporting.TextBox textBox100;
        private Telerik.Reporting.TextBox textBox102;
        private Telerik.Reporting.TextBox textBox19;
        private Telerik.Reporting.TextBox textBox21;
        private Telerik.Reporting.TextBox textBox23;
        private Telerik.Reporting.TextBox textBox25;
        private Telerik.Reporting.TextBox textBox31;
        private Telerik.Reporting.TextBox textBox85;
        private Telerik.Reporting.TextBox textBox24;
        private Telerik.Reporting.TextBox textBox22;
        private Telerik.Reporting.TextBox textBox20;
        private Telerik.Reporting.TextBox textBox18;
        private Telerik.Reporting.TextBox textBox27;
        private Telerik.Reporting.TextBox textBox28;
        private Telerik.Reporting.TextBox textBox87;
        private Telerik.Reporting.TextBox textBox91;
        private Telerik.Reporting.TextBox textBox93;
        private Telerik.Reporting.TextBox textBox106;
        private Telerik.Reporting.TextBox textBox107;
        private Telerik.Reporting.TextBox textBox95;
        private Telerik.Reporting.TextBox textBox108;
        private Telerik.Reporting.TextBox textBox109;
        private Telerik.Reporting.TextBox textBox99;
        private Telerik.Reporting.TextBox textBox29;
        private Telerik.Reporting.List list3;
        private Telerik.Reporting.TextBox textBox30;
        private Telerik.Reporting.TextBox textBox32;
        private Telerik.Reporting.TextBox OPSFeeNachYes;
        private Telerik.Reporting.TextBox textBox36;
        private Telerik.Reporting.TextBox OPSFeeNachNo;
        private Telerik.Reporting.List list5;
        private Telerik.Reporting.TextBox textBox33;
        private Telerik.Reporting.TextBox textBox35;
        private Telerik.Reporting.TextBox DopTarFeeNachYes;
        private Telerik.Reporting.TextBox textBox39;
        private Telerik.Reporting.TextBox DopTarFeeNachNo;
        private Telerik.Reporting.TextBox textBox34;
        private Telerik.Reporting.TextBox textBox37;
        private Telerik.Reporting.TextBox textBox46;
        private Telerik.Reporting.TextBox ConfirmDolgn;
        private Telerik.Reporting.TextBox textBox55;
        private Telerik.Reporting.TextBox textBox56;
        private Telerik.Reporting.TextBox ConfirmFIO;
        private Telerik.Reporting.TextBox textBox57;
        private Telerik.Reporting.TextBox DateFilling;
        private Telerik.Reporting.TextBox textBox58;
        private Telerik.Reporting.TextBox textBox38;
        private Telerik.Reporting.Table table1;
        private Telerik.Reporting.TextBox textBox43;
        private Telerik.Reporting.TextBox textBox49;
        private Telerik.Reporting.TextBox textBox51;
        private Telerik.Reporting.TextBox textBox41;
        private Telerik.Reporting.TextBox textBox47;
        private Telerik.Reporting.TextBox textBox50;
        private Telerik.Reporting.TextBox textBox52;
        private Telerik.Reporting.TextBox textBox53;
    }
}